module.exports = {
  devServer: {
    proxy: 'http://localhost:5000'
  }
}