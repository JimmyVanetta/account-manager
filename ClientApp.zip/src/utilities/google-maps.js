/**
 * Helpers for reusing Google Maps instances (important for single-page apps, modals, etc).
 */

/**
 * @type {{ element: HTMLDivElement, map: google.maps.Map }}
 */
let INSTANCE = null;

/**
 * Attach the shared Google Map to a div.
 * @param {HTMLElement} parentElement
 */
export function attachMap(parentElement) {
  if (!INSTANCE) {
    let element = document.createElement("div");
    element.style.width = "100%";
    element.style.height = "100%";
    // eslint-disable-next-line no-undef
    let map = new window.google.maps.Map(element);
    INSTANCE = { element, map };
  }

  parentElement.appendChild(INSTANCE.element);
}

/**
 * @returns {google.maps.Map}
 */
export function getMap() {
  if (!INSTANCE) {
    return null;
  }
  return INSTANCE.map;
}
