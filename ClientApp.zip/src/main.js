import Vue from 'vue'
import App from './App.vue'
import store from './store'
import VueRouter from 'vue-router'

import HelloWorld from "./components/HelloWorld.vue";
import ProviderAccounts from "./views/ProviderAccounts.vue";
import InvoiceUnbilled from "./views/InvoiceUnbilled.vue";
import ProviderMap from "./views/ProviderMap.vue";
import ProviderDashboard from "./views/ProviderDashboard.vue";

import { library } from '@fortawesome/fontawesome-svg-core';
import { faDollarSign, faFileInvoiceDollar, faAddressBook, faHandHoldingUsd, faEdit, faTrash, faEllipsisH, faInfo } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome';
import axios from 'axios';
import VueAxios from 'vue-axios';

library.add(faDollarSign);
library.add(faFileInvoiceDollar);
library.add(faAddressBook);
library.add(faHandHoldingUsd);
library.add(faEdit);
library.add(faTrash);
library.add(faEllipsisH);
library.add(faInfo);
Vue.use(VueAxios, axios)
Vue.component('font-awesome-icon', FontAwesomeIcon)

const routes = [
  { path: '/', component: HelloWorld },
  { path: '/Grid', component: ProviderDashboard },
  { path: '/Accounts', component: ProviderAccounts },
  { path: '/rates', component: HelloWorld },
  { path: '/UnbilledJobs', component: InvoiceUnbilled },
  { path: '/Maps', component: ProviderMap },
]
const router = new VueRouter({
  mode: 'history',
  routes // short for `routes: routes`
})
Vue.use(VueRouter)

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App),
}).$mount('#app')
