

const _mockData = [
  {
    "itemCode": "TOW",
    "itemName": "Towing",
    "isObsolete": false,
    "isTaxable": true,
    "itemDesc": null,
    "itemRates": [
      {
        "jobTypeId": 21,
        "rateId": 32,
        "accountId": 257,
        "priority": 0,
        "amount": "155.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Mileage Item Rate",
          "mileageSource": 3
        }
      },
      {
        "jobTypeId": 22,
        "rateId": 33,
        "accountId": 256,
        "priority": 0,
        "amount": "155.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 34,
        "accountId": 255,
        "priority": 0,
        "amount": "100.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 32,
        "accountId": 257,
        "priority": 0,
        "amount": "50.00",
        "tierCount": null,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 31,
        "accountId": 255,
        "priority": 0,
        "amount": "7.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 21,
        "rateId": 31,
        "accountId": 255,
        "priority": 0,
        "amount": "2.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 21,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "45454.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 35,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "45454.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 23,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "45454.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 22,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "45454.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "45454.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 21,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "11.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      }
    ]
  },
  {
    "itemCode": "Tax",
    "itemName": "Taxes",
    "isObsolete": false,
    "isTaxable": true,
    "itemDesc": null,
    "itemRates": [
      {
        "jobTypeId": 21,
        "rateId": 32,
        "accountId": 257,
        "priority": 0,
        "amount": "0.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 22,
        "rateId": 33,
        "accountId": 256,
        "priority": 0,
        "amount": "0.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 34,
        "accountId": 255,
        "priority": 0,
        "amount": "0.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 32,
        "accountId": 257,
        "priority": 0,
        "amount": "25.00",
        "tierCount": null,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 31,
        "accountId": 256,
        "priority": 0,
        "amount": "2.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 22,
        "rateId": 31,
        "accountId": 256,
        "priority": 0,
        "amount": "2.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 35,
        "rateId": 31,
        "accountId": 256,
        "priority": 0,
        "amount": "2.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 23,
        "rateId": 31,
        "accountId": 256,
        "priority": 0,
        "amount": "2.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 21,
        "rateId": 31,
        "accountId": 256,
        "priority": 0,
        "amount": "2.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 21,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "880.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 22,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "880.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 23,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "880.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "880.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 35,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "880.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 21,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "66.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "66.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 22,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "66.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 35,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "66.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 23,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "66.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      }
    ]
  },
  {
    "itemCode": "STOR",
    "itemName": "Storage",
    "isObsolete": false,
    "isTaxable": true,
    "itemDesc": null,
    "itemRates": [
      {
        "jobTypeId": 20,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "0.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 21,
        "rateId": 32,
        "accountId": 257,
        "priority": 0,
        "amount": "20.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Mileage Item Rate",
          "isCalendarDay": false,
          "unit": null
        }
      },
      {
        "jobTypeId": 22,
        "rateId": 33,
        "accountId": 256,
        "priority": 0,
        "amount": "20.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Mileage Item Rate",
          "isCalendarDay": false,
          "unit": null
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 34,
        "accountId": 255,
        "priority": 1,
        "amount": "1.00",
        "tierCount": 1,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 34,
        "accountId": 255,
        "priority": 0,
        "amount": "2.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 31,
        "accountId": null,
        "priority": 1,
        "amount": "2.00",
        "tierCount": 1,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 21,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "66.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 35,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "66.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 23,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "66.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 22,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "66.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "555.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      }
    ]
  },
  {
    "itemCode": "LBR",
    "itemName": "Labor",
    "isObsolete": false,
    "isTaxable": false,
    "itemDesc": "test",
    "itemRates": [
      {
        "jobTypeId": 20,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "0.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 21,
        "rateId": 32,
        "accountId": 257,
        "priority": 0,
        "amount": "0.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 22,
        "rateId": 33,
        "accountId": 256,
        "priority": 0,
        "amount": "50.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 32,
        "accountId": 257,
        "priority": 1,
        "amount": "60.00",
        "tierCount": 1,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 32,
        "accountId": 257,
        "priority": 1,
        "amount": "60.00",
        "tierCount": 1,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 32,
        "accountId": 257,
        "priority": 1,
        "amount": "60.00",
        "tierCount": 1,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 32,
        "accountId": 257,
        "priority": 1,
        "amount": "5.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "121.00",
        "tierCount": null,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 21,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "121.00",
        "tierCount": null,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 35,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "121.00",
        "tierCount": null,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 22,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "121.00",
        "tierCount": null,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 23,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "121.00",
        "tierCount": null,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 23,
        "rateId": 34,
        "accountId": 255,
        "priority": 0,
        "amount": "2.00",
        "tierCount": null,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 21,
        "rateId": 34,
        "accountId": 255,
        "priority": 0,
        "amount": "2.00",
        "tierCount": null,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 35,
        "rateId": 34,
        "accountId": 255,
        "priority": 0,
        "amount": "2.00",
        "tierCount": null,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 22,
        "rateId": 34,
        "accountId": 255,
        "priority": 0,
        "amount": "2.00",
        "tierCount": null,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 34,
        "accountId": 255,
        "priority": 1,
        "amount": "1.00",
        "tierCount": 1,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 34,
        "accountId": 255,
        "priority": 0,
        "amount": "2.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 31,
        "accountId": null,
        "priority": 1,
        "amount": "2.00",
        "tierCount": 1,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 31,
        "accountId": null,
        "priority": 1,
        "amount": "2.00",
        "tierCount": 1,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 21,
        "rateId": 31,
        "accountId": 255,
        "priority": 0,
        "amount": "121.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 33,
        "accountId": null,
        "priority": 1,
        "amount": "10.00",
        "tierCount": 10,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 21,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "50.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Mileage Item Rate",
          "mileageSource": 3
        }
      },
      {
        "jobTypeId": 23,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "50.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Mileage Item Rate",
          "mileageSource": 3
        }
      },
      {
        "jobTypeId": 22,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "50.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Mileage Item Rate",
          "mileageSource": 3
        }
      },
      {
        "jobTypeId": 35,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "50.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Mileage Item Rate",
          "mileageSource": 3
        }
      },
      {
        "jobTypeId": 21,
        "rateId": 33,
        "accountId": null,
        "priority": 1,
        "amount": "10.00",
        "tierCount": 10,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 23,
        "rateId": 33,
        "accountId": null,
        "priority": 1,
        "amount": "10.00",
        "tierCount": 10,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 35,
        "rateId": 33,
        "accountId": null,
        "priority": 1,
        "amount": "10.00",
        "tierCount": 10,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 22,
        "rateId": 33,
        "accountId": null,
        "priority": 1,
        "amount": "10.00",
        "tierCount": 10,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "50.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Mileage Item Rate",
          "mileageSource": 3
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 33,
        "accountId": null,
        "priority": 1,
        "amount": "10.00",
        "tierCount": 10,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 32,
        "accountId": null,
        "priority": 0,
        "amount": "2.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 21,
        "rateId": 32,
        "accountId": null,
        "priority": 0,
        "amount": "2.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 35,
        "rateId": 32,
        "accountId": null,
        "priority": 0,
        "amount": "2.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 23,
        "rateId": 32,
        "accountId": null,
        "priority": 0,
        "amount": "2.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 22,
        "rateId": 32,
        "accountId": null,
        "priority": 0,
        "amount": "2.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      }
    ]
  },
  {
    "itemCode": "FEE",
    "itemName": "Add. Fee",
    "isObsolete": false,
    "isTaxable": false,
    "itemDesc": null,
    "itemRates": []
  },
  {
    "itemCode": "ADMI",
    "itemName": "Admin Fees",
    "isObsolete": false,
    "isTaxable": false,
    "itemDesc": null,
    "itemRates": [
      {
        "jobTypeId": 21,
        "rateId": 32,
        "accountId": 257,
        "priority": 0,
        "amount": "25.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 22,
        "rateId": 33,
        "accountId": 256,
        "priority": 0,
        "amount": "25.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 32,
        "accountId": 257,
        "priority": 0,
        "amount": "50.00",
        "tierCount": null,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 21,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "0.00",
        "tierCount": null,
        "isDirty": false,
        "data": {
          "name": "Mileage Item Rate",
          "mileageSource": 3
        }
      },
      {
        "jobTypeId": 35,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "0.00",
        "tierCount": null,
        "isDirty": false,
        "data": {
          "name": "Mileage Item Rate",
          "mileageSource": 3
        }
      },
      {
        "jobTypeId": 22,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "0.00",
        "tierCount": null,
        "isDirty": false,
        "data": {
          "name": "Mileage Item Rate",
          "mileageSource": 3
        }
      },
      {
        "jobTypeId": 23,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "0.00",
        "tierCount": null,
        "isDirty": false,
        "data": {
          "name": "Mileage Item Rate",
          "mileageSource": 3
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 34,
        "accountId": 255,
        "priority": 0,
        "amount": "5.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Mileage Item Rate",
          "mileageSource": 3
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 31,
        "accountId": null,
        "priority": 1,
        "amount": "1.00",
        "tierCount": 2,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 32,
        "accountId": 257,
        "priority": 1,
        "amount": "1.00",
        "tierCount": 1,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 32,
        "accountId": 257,
        "priority": 2,
        "amount": "0.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 31,
        "accountId": null,
        "priority": 2,
        "amount": "1.00",
        "tierCount": 1,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 32,
        "accountId": 255,
        "priority": 0,
        "amount": "2.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Mileage Item Rate",
          "mileageSource": 3
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 31,
        "accountId": null,
        "priority": 1,
        "amount": "0.00",
        "tierCount": 3,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 31,
        "accountId": null,
        "priority": 2,
        "amount": "2.00",
        "tierCount": 5,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "5.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 21,
        "rateId": 31,
        "accountId": 255,
        "priority": 0,
        "amount": "5.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Mileage Item Rate",
          "mileageSource": 2
        }
      },
      {
        "jobTypeId": 22,
        "rateId": 31,
        "accountId": 255,
        "priority": 0,
        "amount": "5.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Mileage Item Rate",
          "mileageSource": 2
        }
      },
      {
        "jobTypeId": 23,
        "rateId": 31,
        "accountId": 255,
        "priority": 0,
        "amount": "5.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Mileage Item Rate",
          "mileageSource": 2
        }
      },
      {
        "jobTypeId": 35,
        "rateId": 31,
        "accountId": 255,
        "priority": 0,
        "amount": "5.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Mileage Item Rate",
          "mileageSource": 2
        }
      },
      {
        "jobTypeId": 21,
        "rateId": 31,
        "accountId": 255,
        "priority": 1,
        "amount": "2.00",
        "tierCount": 10,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 22,
        "rateId": 31,
        "accountId": 255,
        "priority": 1,
        "amount": "2.00",
        "tierCount": 10,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 23,
        "rateId": 31,
        "accountId": 255,
        "priority": 1,
        "amount": "2.00",
        "tierCount": 10,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 35,
        "rateId": 31,
        "accountId": 255,
        "priority": 1,
        "amount": "2.00",
        "tierCount": 10,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 21,
        "rateId": 31,
        "accountId": 255,
        "priority": 2,
        "amount": "5.00",
        "tierCount": 50,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 22,
        "rateId": 31,
        "accountId": 255,
        "priority": 2,
        "amount": "5.00",
        "tierCount": 50,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 23,
        "rateId": 31,
        "accountId": 255,
        "priority": 2,
        "amount": "5.00",
        "tierCount": 50,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 35,
        "rateId": 31,
        "accountId": 255,
        "priority": 2,
        "amount": "5.00",
        "tierCount": 50,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 31,
        "accountId": 255,
        "priority": 0,
        "amount": "5.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "TimeLimeItemRate",
          "startJobEventId": 53,
          "stopJobEventId": 87,
          "round": 60.000000
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 31,
        "accountId": 255,
        "priority": 1,
        "amount": "2.00",
        "tierCount": 11,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 31,
        "accountId": 255,
        "priority": 2,
        "amount": "5.00",
        "tierCount": 50,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 32,
        "accountId": null,
        "priority": 0,
        "amount": "25.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      }
    ]
  },
  {
    "itemCode": "ML",
    "itemName": "Unloaded Mileage",
    "isObsolete": false,
    "isTaxable": true,
    "itemDesc": "",
    "itemRates": [
      {
        "jobTypeId": 20,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "22.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      }
    ]
  },
  {
    "itemCode": "UNMI",
    "itemName": "Unloaded Mileage",
    "isObsolete": false,
    "isTaxable": true,
    "itemDesc": "",
    "itemRates": [
      {
        "jobTypeId": 23,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "55.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 21,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "55.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 35,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "55.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 22,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "55.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "55.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      }
    ]
  },
  {
    "itemCode": "TES1",
    "itemName": "Test1",
    "isObsolete": false,
    "isTaxable": false,
    "itemDesc": "",
    "itemRates": [
      {
        "jobTypeId": 20,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "100.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 22,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "100.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 21,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "100.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 35,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "100.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 23,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "100.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "45.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 23,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "45.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 22,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "45.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 21,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "45.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 35,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "45.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      }
    ]
  },
  {
    "itemCode": "TES2",
    "itemName": "Test 2",
    "isObsolete": false,
    "isTaxable": false,
    "itemDesc": "",
    "itemRates": [
      {
        "jobTypeId": 20,
        "rateId": 33,
        "accountId": null,
        "priority": 0,
        "amount": "76.00",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      },
      {
        "jobTypeId": 20,
        "rateId": 31,
        "accountId": null,
        "priority": 0,
        "amount": "123123.12",
        "tierCount": 0,
        "isDirty": false,
        "data": {
          "name": "Flat Item Rate"
        }
      }
    ]
  }
]





;


export default {
    getAllItemRates(cb){
        setTimeout(() => cb(_mockData), 100)
    }
}

