const _mockData = [
    {
      accountId: null,
      accountName: "General/Global",
    },
    {
      "accountId": 255,
      "accountName": "Customer/Cash"
    },
    {
      "accountId": 256,
      "accountName": "Reynoldsburg PD"
    },
    {
      "accountId": 257,
      "accountName": "Whitehall PD"
    },
  ];


export default {
    getAllAccounts(cb){
        setTimeout(() => cb(_mockData), 100)
    }
}