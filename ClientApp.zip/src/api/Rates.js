

const _mockData =[
  {
    "rateId": 31,
    "rateName": "Customer/Cash"
  },
  {
    "rateId": 32,
    "rateName": "Light Duty Tow"
  },
  {
    "rateId": 33,
    "rateName": "Tow"
  },
  {
    "rateId": 34,
    "rateName": "Towing"
  }
]



;
function delay(t, v) {
  return new Promise(function(resolve) { 
      setTimeout(resolve.bind(null, v()), t)
  });
}
export default {
    getAllRates(){
        return delay(100, () => {return _mockData});
    }
}

