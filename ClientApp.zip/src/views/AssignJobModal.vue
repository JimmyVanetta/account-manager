<template>
  <div >
    <base-modal
      :showModal="isOpen"
      title="Create New Call"
      :actions='[
      {
        Text: "Save Call",
        callback: handleOnSaveClick,
      },
    ]'

    @onCloseModal="closeModal"
    >
    <div class="w-1/2">
      <div class="flex w-96">
        <div class="flex-1 text-right ml-10">
        test
          
        </div>
      </div>
      </div>
    </base-modal>
  </div>
</template>

<script>
import BaseModal from "../components/BaseModal.vue";

export default {
  components: { BaseModal },
  data(){
    return{
      selfClose: false
    }
  },
  props: {
    isOpen: Boolean,
  },
  computed: {
    showModal(){
      return this.isOpen && !this.selfClose;
    }
  },
  methods: {
    closeModal(){
      this.$emit("onCloseModal");

    },
  handleOnSaveClick(){
  }
  },
  
};
</script>