<template>

   <div class="mx-3 mt-3 flex-no-wrap w-full">
      <div class="">
        <div
          class="py-2 p-4 rounded-t flex items-center justify-between bg-tracker-blue shadow-md border-l border-r border-t border-black"
        >
          <h1 class="text-white font-bold text-xl">Un-billed jobs</h1>
          <div>

          </div>
        </div>
        <div class="w-full  bg-white border-1" style="max-height: 80vh; overflow-y: auto">
            
        <table 
        style="width: 100%"
            class="bg-white shadow-md rounded border tracker-border-gray rateTable"
        >
            <thead>
                <tr>
                    <td>Account Name</td>
                    <td>Contact Name</td>
                    <td>Contact Phone</td>
                    <td>Job #</td>
                    <td>Call Date</td>
                    <td>Date Completed</td>
                    <td>Sub Total</td>
                    <td>Taxes</td>
                    <td>Total</td>
                    <td style="width:9em"></td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>ACTIVE USA, INC</td>
                    <td>Jane Doe</td>
                    <td>555-555-5555</td>
                    <td>375</td>
                    <td>12/18/2020 7:10 PM</td>
                    <td>12/18/2020 9:10 PM</td>
                    <td style="text-align:right">$120.00</td>
                    <td style="text-align:right">$12.00</td>
                    <td style="text-align:right">$132.00</td>
                    <td>
                        <font-awesome-icon icon="file-invoice-dollar" class="ml-2" />
                        <font-awesome-icon icon="edit"  class="ml-2" />
                    </td>
                </tr>
                
            </tbody>
        </table>
        </div>
      </div>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>