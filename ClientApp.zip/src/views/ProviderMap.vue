/* eslint-disable no-undef */
/* eslint-disable no-undef */
<template>
    <div class="h-1/2 w-1/2 flex flex-col" >
        <div id="trackerMap" ref="map" class="flex-1">
            <map-marker :lat="mark.lat" :lng="mark.lng" :key="mark.lat" v-for="mark in markers"></map-marker>
        </div>
    </div>
</template>

<script>
    import { attachMap, getMap } from "@/utilities/google-maps";
    import MapMarker from "../components/MapMarker.vue";

    export default {
        components: { MapMarker },
        data() {
            return {
                markers: [
                    { lat: -27.334, lng: 133.036 },
                    { lat: -17.334, lng: 120.036 },
                ],
                timerCount: 3
            };
        },
        methods: {
            getMap(callback) {
                let vm = this;
                function checkForMap() {
                    if (vm.map) callback(vm.map);
                    else setTimeout(checkForMap, 200);
                }
                checkForMap();
            },
        },
        watch: {

            timerCount: {
                handler(value) {

                    if (value > 0) {
                        setTimeout(() => {

                            this.timerCount--;
                        }, 1000);
                    } else {
                        this.timerCount = 3;
                        this.markers[0].lat += .010;
                        this.markers[0].lat += .010;
                    }

                },
                immediate: true // This ensures the watcher is triggered upon creation
            }

        },
        mounted() {
            console.log(this.$refs.map)
            attachMap(this.$refs.map);
            this.map = getMap();
            console.log(this.map)

            this.map.setOptions({
                clickableIcons: true,
                mapTypeControl: true,
                mapTypeControlOptions: {
                    // eslint-disable-next-line no-undef
                    style: google.maps.MapTypeControlStyle.DROPDOWN_MENU,
                    // eslint-disable-next-line no-undef
                    position: google.maps.ControlPosition.TOP_RIGHT,
                },
                fullscreenControl: false,
                center: { lat: -25.344, lng: 131.036 },
                zoom: 4,
            });
        },
    };
</script>

<style>
</style>