<template>
  <div class="mx-3 mt-3 flex-no-wrap w-full">
    <div class="">
      <div
        class="py-2 p-4 rounded-t flex items-center justify-between bg-tracker-blue shadow-md border-l border-r border-t border-black"
      >
        <h1 class="text-white font-bold text-xl">Accounts</h1>
        <div>
          <button class="btn mx-2">New <u>A</u>ccount</button>
        </div>
      </div>
      <div
        class="w-full bg-white border-1"
        style="max-height: 80vh; overflow-y: auto; padding: 15px"
      >
        <div class="flex justify-around text-center my-2">
          <button
            class="btn"
            style="background-color: lightyellow; color: gray"
            @click="onUnbilledJobsClick"
          >
            <p>Unbilled Jobs</p>
            <p>$357.50</p>
          </button>
          <button
            class="btn"
            @click="showOutstandingInvoices = true"
            style="background-color: lightgreen; color: gray"
          >
            <p>Outstanding Invoices</p>
            <p>$2,000.00</p>
          </button>
          <button
            class="btn"
            @click="showPastDueInvoices = true"
            style="background-color: lightpink; color: gray"
          >
            <p>Past Due Invoices</p>
            <p>$1,513.00</p>
          </button>
        </div>
        <table
          style="width: 100%"
          class="bg-white mt-5 shadow-md rounded border tracker-border-gray rateTable"
        >
          <thead class="accounts">
            <tr>
              <th style="width: 5em">Code</th>
              <th>Account Name</th>
              <th>Primary Contact</th>
              <th>Phone</th>
              <th>Unbilled Jobs</th>
              <th>Outstanding Invoices</th>
              <th>Past Due Invoice</th>
              <th>Balance</th>
              <th style="width: 9em"></th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>ACTT</td>
              <td>ACTIVE USA, INC</td>
              <td>Jane Doe</td>
              <td>555-555-5555</td>
              <td style="text-align: right">$0.00</td>
              <td style="text-align: right">$2,000.00</td>
              <td style="text-align: right">$0.00</td>
              <td style="text-align: right">$0.00</td>
              <td>
                <font-awesome-icon icon="trash" class="ml-2" />
                <font-awesome-icon icon="file-invoice-dollar" class="ml-2" />
                <font-awesome-icon icon="address-book" class="ml-2" />
                <font-awesome-icon icon="hand-holding-usd" class="ml-2" />
                <font-awesome-icon icon="edit" class="ml-2" />
              </td>
            </tr>
            <tr>
              <td>ACCC</td>
              <td>Advanced car care center</td>
              <td>Jane Doe</td>
              <td>555-555-5555</td>
              <td style="text-align: right">$0.00</td>
              <td style="text-align: right">$1,000.00</td>
              <td style="text-align: right">$2,000.00</td>
              <td style="text-align: right">$1,500.00</td>
              <td>
                <font-awesome-icon
                  title="Delete Account"
                  icon="trash"
                  class="ml-2"
                />
                <font-awesome-icon
                  title="Create Invoice"
                  icon="file-invoice-dollar"
                  class="ml-2"
                />
                <font-awesome-icon
                  title="Contacts"
                  icon="address-book"
                  class="ml-2"
                />
                <font-awesome-icon
                  title="Add Payment"
                  icon="hand-holding-usd"
                  class="ml-2"
                />
                <font-awesome-icon
                  title="Edit Account"
                  icon="edit"
                  class="ml-2"
                />
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <base-modal
      title="Unbilled Jobs"
      :showModal="showUnbilledJobs"
      @onCloseModal="showUnbilledJobs = false"
    >
      <table
        style="width: 100%"
        class="bg-white shadow-md rounded border tracker-border-gray rateTable"
      >
        <thead>
          <tr>
            <th>Account Name</th>
            <th>Contact Name</th>
            <th>Contact Phone</th>
            <th>Job #</th>
            <th>Call Date</th>
            <th>Date Completed</th>
            <th>Sub Total</th>
            <th>Taxes</th>
            <th>Total</th>
            <th style="width: 9em"></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>ACTIVE USA, INC</td>
            <td>Jane Doe</td>
            <td>555-555-5555</td>
            <td>375</td>
            <td>12/18/2020 7:10 PM</td>
            <td>12/18/2020 9:10 PM</td>
            <td style="text-align: right">$325.00</td>
            <td style="text-align: right">$32.50</td>
            <td style="text-align: right">$357.50</td>
            <td>
              <font-awesome-icon
                title="Create Invoice"
                icon="file-invoice-dollar"
                class="ml-2"
                @click="onCreateInvoice(375)"
              />
              <font-awesome-icon title="Edit Job" icon="edit" class="ml-2" />
            </td>
          </tr>
        </tbody>
      </table>
    </base-modal>
    <base-modal
      title="Outstanding Invoices"
      :showModal="showOutstandingInvoices"
      @onCloseModal="showOutstandingInvoices = false"
    >
      <table
        style="width: 100%"
        class="bg-white shadow-md rounded border tracker-border-gray rateTable"
      >
        <thead>
          <tr>
            <th>Account Name</th>
            <th>Contact Name</th>
            <th>Contact Phone</th>
            <th>Invoice #</th>
            <th>Invoice Date</th>
            <th>Date Due</th>
            <th>Sub Total</th>
            <th>Taxes</th>
            <th>Total</th>
            <th style="width: 9em"></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>ACTIVE USA, INC</td>
            <td>Jane Doe</td>
            <td>555-555-5555</td>
            <td>376-1</td>
            <td>12/18/2020</td>
            <td>1/27/2021</td>
            <td style="text-align: right">$5000.00</td>
            <td style="text-align: right">$500.00</td>
            <td style="text-align: right">$5500.00</td>
            <td>
              <font-awesome-icon
                title="Apply Payment"
                icon="hand-holding-usd"
                class="ml-2"
              />
              <font-awesome-icon
                title="Edit Invoice"
                icon="edit"
                class="ml-2"
              />
            </td>
          </tr>
        </tbody>
      </table>
    </base-modal>
    <base-modal
      title="Past Due Invoices"
      :showModal="showPastDueInvoices"
      @onCloseModal="showPastDueInvoices = false"
    >
      <table
        style="width: 100%"
        class="bg-white shadow-md rounded border tracker-border-gray rateTable"
      >
        <thead>
          <tr>
            <th>Account Name</th>
            <th>Contact Name</th>
            <th>Contact Phone</th>
            <th>Invoice #</th>
            <th>Invoice Date</th>
            <th>Date Due</th>
            <th>Sub Total</th>
            <th>Taxes</th>
            <th>Total</th>
            <th style="width: 9em"></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>ACTIVE USA, INC</td>
            <td>Jane Doe</td>
            <td>555-555-5555</td>
            <td>376-1</td>
            <td>12/18/2020</td>
            <td>1/27/2021</td>
            <td style="text-align: right">$5000.00</td>
            <td style="text-align: right">$500.00</td>
            <td style="text-align: right">$5500.00</td>
            <td>
              <font-awesome-icon
                title="Apply Payment"
                icon="hand-holding-usd"
                class="ml-2"
              />
              <font-awesome-icon
                title="Edit Invoice"
                icon="edit"
                class="ml-2"
              />
            </td>
          </tr>
        </tbody>
      </table>
    </base-modal>

    <base-modal
      title="Create Invoice"
      :showModal="showCreateInvoice"
      :actions="[
        {
          Text: 'Save Invoice',
          callback: () => {
            alert('save Invoice');
          },
          shortkey: ['alt', 'i'],
        },
        {
          Text: 'Save & Email',
          callback: () => {
            alert('save Invoice');
          },
          shortkey: ['alt', 'i'],
        },
      ]"
      @onCloseModal="showCreateInvoice = false"
    >
      <div class="relative flex h-full">


        <div class="flex-auto pt-4 pr-2 pb-4 border-r" style="width:65%">
        <div class="flex flex-row content-between">
          <div style="width:15%" class="px-2">
            <label class="mb-2 text-tracker-grey text-sm ">Invoice No:</label>
            <input type="text" class="form-input focus:bg-white" style="border: 1px solid red;" value="375-1">
            <p class="text-xs">Invoice No Rquired</p>
          </div>
          <div style="width:35%" class="  px-2">
            <label class="mb-2 text-tracker-grey text-sm ">Account:</label>
            <select class="form-input">
              <option>ACTIVE USA, INC</option>
            </select>
          </div>
          <div class="w-1/4 px-2">
            <label class="mb-2 text-tracker-grey text-sm ">Invoice Date:</label>
            <input type="date" class="form-input focus:bg-white" value="2021-01-03"/>
          <p class="text-xs"></p>
          </div>
          <div class="w-1/4  px-2">
            <label class="mb-2 text-tracker-grey text-sm ">Terms:</label>
            <select class="form-input">
              <option>Upon Receipt</option>
              <option>30 Days</option>
              <option>60 Days</option>
              <option>90 Days</option>
            </select>
          <p class="text-xs"></p>
          </div>
        </div>
        <div class="flex flex-row content-between py-2">
          <div class="w-1/2  px-2">
            <label class="mb-2 text-tracker-grey text-sm ">Bill to name:</label>
            <input type="text" class="form-input focus:bg-white" value="Jane Doe"/>
          <p class="text-xs"></p>
          </div>
          <div class="w-1/2  px-2">
            <label class="mb-2 text-tracker-grey text-sm ">Bill to address:</label>
            <input type="text" class="form-input focus:bg-white" value="123 Test Lane, Test Valley OH 44281"/>
          <p class="text-xs"></p>
          </div>
        </div>
        <div class="flex flex-row content-between py-2 ">
          <div class="w-1/2  px-2" style="height:20%">
            <label class="mb-2 text-tracker-grey text-sm ">Job Description:</label>
            <textarea style="height:20%" class=" form-input focus:bg-white h-10 overflow-y-auto text-sm" rows="8" cols="40">All changes are related to those sections when you can do these things. To protect your rights, we need to ensure GFDL compatibility. Re-use of text: Attribution: To re-distribute a text file distributed as part of Derivative Works. You may create a Larger Work; and (b) under Patent Claims infringed by the Copyright Holder's procedures. Contributed a Contribution to the Package, you should contact the Copyright Holder, but only to the Covered Code. You may modify your copy of the provisions of this definition, "control" means (a) the Source Code or twelve (12) months after the Modification is derived, directly or indirectly, from Original Code as ?Multiple-Licensed?.</textarea>
          <p class="text-xs"></p>
          </div>
          <div class="w-1/2  px-2" style="height:20%">
            <label class="mb-2 text-tracker-grey text-sm ">Job Details:</label>
            <textarea style="height:20%" class=" form-input focus:bg-white h-10 overflow-y-auto text-sm" rows="8" cols="40">All changes are related to those sections when you can do these things. To protect your rights, we need to ensure GFDL compatibility. Re-use of text: Attribution: To re-distribute a text file distributed as part of Derivative Works. You may create a Larger Work; and (b) under Patent Claims infringed by the Copyright Holder's procedures. Contributed a Contribution to the Package, you should contact the Copyright Holder, but only to the Covered Code. You may modify your copy of the provisions of this definition, "control" means (a) the Source Code or twelve (12) months after the Modification is derived, directly or indirectly, from Original Code as ?Multiple-Licensed?.</textarea>
          <p class="text-xs"></p>
          </div>
        </div>
         <div class="flex flex-row content-between py-2">
          <div class="w-1/2  px-2">
            <label class="mb-2 text-tracker-grey text-sm ">Pick-up:</label>
            <input type="text" class="form-input focus:bg-white" value="123 Test Lane, Test Vally OH 44281"/>
          <p class="text-xs"></p>
          </div>
          <div class="w-1/2  px-2">
            <label class="mb-2 text-tracker-grey text-sm ">Destination:</label>
            <input type="text" class="form-input focus:bg-white" value="123 Test Lane, Test Vally OH 44281"/>
          <p class="text-xs"></p>
          </div>
        </div>




          <!---->
          <h1>Vehciles</h1>
          <div class="flex flex-row flex-wrap">

            <div class="w-1/4 text-sm mt-4 hover:cursor-pointer">
              <div
                class="border rounded mx-2 p-2 bg-tracker-grey-lightest shadow-outline"
              >
                <span class="font-bold">Vehicle 1</span>
                <div class="text-xs">
                  <span>Owner: <p>Unknown</p></span>
                  <p>UNKNOWN</p>
                  <span>VIN: <p>N/A</p></span>
                </div>
              </div>
            </div>
            <div class="w-1/4 text-sm mt-4 hover:cursor-pointer">
              <div
                class="border rounded mx-2 p-2 bg-tracker-grey-lightest shadow-outline"
              >
                <span class="font-bold">Vehicle 2</span>
                <div class="text-xs">
                  <span>Owner: <p>Randall Clapper</p></span>
                   <p>2012 FORD F-450</p>
                   <span>VIN: <p>1FDUF4GT6CEB45599</p></span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="flex-auto  flex flex-col content-between pl-2">

            <div class="flex-1">
              <table class="w-full">
                <thead>
                  <tr class="mb-2 text-tracker-grey text-xs font-bold">
                    <th>Name</th>
                    <th class="text-right">Qty</th>
                    <th class="text-right">Rate</th>
                    <th class="text-right">Total</th>
                  </tr>
                </thead>
                <tbody class="mb-2 text-tracker-grey text-sm">
                  <tr>
                    <td class=" w-1/3">Loaded Mileage<p class="text-right text-xs">Hands mizzen draft lateen sail cable chantey flogging interloper.</p></td>
                    <td class="text-right"><input class="text-right" type="number" min='0' max='1' value="1"></td>
                    <td class="text-right">$0.00</td>
                    <td class="text-right">$0.00</td>
                  </tr>
                  <tr>
                    <td class=" w-1/2">Towing<p class="text-right text-xs ">Hands mizzen draft lateen sail cable chantey flogging interloper.</p></td>
                    <td class="text-right"><input  class="text-right" type="number" min='0' max='1' value="1"></td>
                    <td class="text-right">$325.00</td>
                    <td class="text-right">$357.50</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div class="pb-10">
              <table class="w-full">
                <thead class="mb-2 text-tracker-grey text-sm ">
                  <tr class="font-bold text-xs">
                    <th colspan="3">Sub Total</th>
                    <th  class="text-right">$325.00</th>
                  </tr>
                  <tr class="text-xs">
                    <th colspan="3">Tax 1:</th>
                    <th  class="text-right">$32.50</th>
                  </tr>
                  <tr class="text-xs">
                    <th colspan="3">Tax 2:</th>
                    <th  class="text-right">$0.00</th>
                  </tr>
                  <tr  class="font-bold">
                    <th colspan="3">Total:</th>
                    <th class="text-right">$357.50</th>
                  </tr>
                </thead>
              </table>
          </div>
        </div>
      </div>
    </base-modal>
  </div>
</template>
<script>
import BaseModal from "../components/BaseModal.vue";

export default {
  components: { BaseModal },

  data() {
    return {
      showUnbilledJobs: false,
      showOutstandingInvoices: false,
      showPastDueInvoices: false,
      showCreateInvoice: false,
    };
  },
  created(){
      this.axios.get('/weatherforecast').then((response) => {
      console.log('test', response.data)
    });
  },
  methods: {
    onCreateInvoice() {
      this.showUnbilledJobs = false;
      this.showCreateInvoice = true;
    },
    onUnbilledJobsClick(e) {
      e.preventDefault();
      this.showUnbilledJobs = true;
    },
  },
};
</script>

<style>
th {
  text-align: left;
  vertical-align: bottom;
  padding: 5px;
}
tbody.accounts > tr > th {
  background-color: #18a2cf;
  color: whitesmoke;
}
label {
  padding: 0;
  margin: 0;
}
table.rateTable td {
  border: 1px solid #969595;
  padding: 5px;
}
table.rateTable td,
table.rateTable th,
td input {
  cursor: pointer;
}
.jobTypeColumn {
  width: 5em;
}
.jobTypeColumn input[type="text"] {
  border: none;
  width: 100%;
  text-align: right;
}
/* select {
  height: 2em;
  border: 1px solid #969595;
  padding: 5px;
} */

button:focus,
button:active {
  outline: none;
  outline: 0;
}
button:hover {
  -webkit-box-shadow: -5px 5px 0px -2px rgba(0, 0, 0, 0.58);
  -moz-box-shadow: -5px 5px 0px -2px rgba(0, 0, 0, 0.58);
  box-shadow: -5px 5px 0px -2px rgba(0, 0, 0, 0.58);
}
button:active {
  -webkit-box-shadow: inset -5px -5px 5px -2px rgba(0, 0, 0, 0.58);
  -moz-box-shadow: inset -5px -5px 5px -2px rgba(0, 0, 0, 0.58);
  box-shadow: inset -5px -5px 5px -2px rgba(0, 0, 0, 0.58);
}
button:active {
  -webkit-box-shadow: -5px -5px 5px -2px rgba(0, 0, 0, 0.58);
  -moz-box-shadow: -5px -5px 5px -2px rgba(0, 0, 0, 0.58);
  box-shadow: -5px -5px 5px -2px rgba(0, 0, 0, 0.58);
}
*:focus {
  outline: none;
}
.btn {
  color: #18a2cf;
  background-color: #fff;
  font-weight: 700;
  padding: 15px 25px;
  text-align: center;
  cursor: pointer;
  outline: none;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
  border-bottom: 2px solid transparent;
  border-left: 1px solid transparent;
}
.btn:hover {
  background-color: white;
  color: #18a2cf;
  /* border-bottom:2px solid black; */
  border-left: 1px solid #969595;
  border-bottom: 1px solid #969595;
}

.btn:active {
  background-color: white;
  color: #18a2cf;
  box-shadow: none;

  transform: translateY(4px) translateX(-4px);
}

.bg-tracker-blue {
  background-color: #18a2cf;
}
.text-tracker-orange {
  color: #f47424;
}
.btn {
  padding-left: 1.5rem;
  padding-right: 1.5rem;
  padding-top: 0.75rem;
  padding-bottom: 0.75rem;
  border-radius: 0.25rem;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.12), 0 2px 4px 0 rgba(0, 0, 0, 0.08);
  width: auto;
}

.btn:hover {
  background-color: white;
  color: #18a2cf;
  /* border-bottom:2px solid black; */
  border-left: 1px solid #969595;
  border-bottom: 1px solid #969595;
}

.btn:active {
  background-color: white;
  color: #18a2cf;
  box-shadow: none;

  transform: translateY(4px) translateX(-4px);
}
/* The switch - the box around the slider */
.switch {
  position: relative;
  display: inline-block;
  width: 40px;
  height: 24px;
}
/* Hide default HTML checkbox */
.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}
/* The slider */
.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: 0.4s;
  transition: 0.4s;
}
.slider:before {
  position: absolute;
  content: "";
  height: 16px;
  width: 16px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: 0.4s;
  transition: 0.4s;
}
input:checked + .slider {
  background-color: #2196f3;
}
input:focus + .slider {
  box-shadow: 0 0 1px #2196f3;
}
input:checked + .slider:before {
  -webkit-transform: translateX(16px);
  -ms-transform: translateX(16px);
  transform: translateX(16px);
}
/* Rounded sliders */
.slider.round {
  border-radius: 24px;
}
.slider.round:before {
  border-radius: 50%;
}
.border-tracker-blue {
  background-color: #18a2cf;
}
.border-tracker-blue input {
  font-weight: bold;
}

.inactive-item,
.inactive-item input {
  background-color: gray;
  text-decoration: line-through;
}
label {
  display: block;
}
.searchItem {
  height: 2em;
  border: 1px solid #969595;
}
.active-item td {
  height: 37px;
}
.tracker-border-gray {
  border: 1px solid #969595;
}

.form-input,
.form-select {
  display: block;
  height: 3rem;
  padding: 0.75rem;
  width: 100%;
  border-width: 1px;
  border-radius: 0.25rem;
  font-size: 0.875rem;
  line-height: 1;
  background-color: #fcfcfc;
  border-color:#e2e8f0;
}
</style>