<template>
  <div class="mx-3 mt-3 flex-no-wrap w-full">
    <div class="">
      <div
        class="py-2 p-4 rounded-t flex items-center justify-between bg-tracker-blue shadow-md border-l border-r border-t border-black"
      >
        <h1 class="text-white font-bold text-xl">Dispatch Grid</h1>
        <div>
            <div class="flex items-start">
                <div class="input-group">
                    <label for="filter">Filter:</label>
                    <input type="text" class="input" style="border: 1px solid grey" />
                </div>
                <div class="input-group">
                    <label for="filter">Status:</label>
                    <select class="w-full">
                        <option value="">ALL</option>
                        <option v-for="option in availableStatus"
                                :value="option"
                                :key="option"
                                @change="onStatusChange($event, job)">
                            {{ option }}
                        </option>
                    </select>
                </div>
                <div class="input-group">
                    <label for="filter">Accounts:</label>
                    <select class="w-full">
                        <option value="">ALL</option>
                        <option value=""></option>
                    </select>
                </div>
                <div class="input-group">
                    <label for="filter">Tow Type:</label>
                    <select class="w-full">
                        <option value="">ALL</option>
                        <option value=""></option>
                    </select>
                </div>
                <button class="btn mx-2 mt-2">Advance Filter</button>
            </div>
        </div>
      </div>
      <div
        class="w-full bg-white border-1 flex justify-between"
        style="max-height: 82vh; overflow-y: auto; padding: 15px"
      >
      <div
          style="
            width: 10%;
            padding: 5px;
            margin-right: 10px;
            border: 1px solid black;
          "
        >
          <div>Drivers</div>
          <hr />
          <div style="max-height: 95%" class="driverList">
            <ul>
              <li class="online" draggable @dragstart='startDrag($event)'  @drop='onDrop($event, 1)'
      @dragover.prevent
      @dragenter.prevent>
                <p class="text-base">Carolyn Sanchez</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="online">
                <p class="text-base">Joshua Green</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="online">
                <p class="text-base">Sara Rivera</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="online">
                <p class="text-base">Jessica Anderson</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="online">
                <p class="text-base">Jose Rogers</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="online">
                <p class="text-base">Sandra Taylor</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="online">
                <p class="text-base">Julia Thomas</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="online">
                <p class="text-base">Martha Campbell</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="online">
                <p class="text-base">Aaron Nelson</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="online">
                <p class="text-base">Angela Hill</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="online">
                <p class="text-base">Brenda Mitchell</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="offline">
                <p class="text-base">Andrew Rodriguez</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="offline">
                <p class="text-base">Roy Griffin</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="offline">
                <p class="text-base">Juan Gonzales</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="offline">
                <p class="text-base">Emily Johnson</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="offline">
                <p class="text-base">Adam Diaz</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="offline">
                <p class="text-base">Cheryl Jackson</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="offline">
                <p class="text-base">Beverly Gonzalez</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="offline">
                <p class="text-base">Jonathan Clark</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="offline">
                <p class="text-base">Maria Davis</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="offline">
                <p class="text-base">Larry Morgan</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="offline">
                <p class="text-base">Sean James</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="offline">
                <p class="text-base">Paula Hernandez</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="offline">
                <p class="text-base">Earl Parker</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
              <li class="offline">
                <p class="text-base">Joan Martin</p>
                <p class="text-sm"><i>Truck: 300 - Heavy</i></p>
              </li>
            </ul>
          </div>
        </div>
        <div style="width: 90%">
          <table class="w-full jobTable" border="1">
            <thead>
              <tr>
                <th style="width: 3%">#</th>
                <th style="width: 6%">Account</th>
                <th style="width: 12%">Status</th>
                <th style="width: 12%">Last Updated</th>
                <th style="width: 7.5%">Job Duration</th>
                <th style="width: 7.5%">ETA</th>
                <th style="width: 7.5%">Tow Type</th>
                <th style="width: 7.5%">Driver</th>
                <th style="width: 15%">Vehicle(s)</th>
                <th style="width: 15%">Pickup Location</th>
                <th style="width: 15%">Dropoff Location</th>
                <th style="width: 120px">Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="job in activeJobs" :key="job.jobNo"    @drop='onDrop($event, job.jobNo)'
      @dragover.prevent
      @dragenter.prevent
                  draggable="true"  @dragstart='startDrag($event)'>
                <td >{{ job.jobNo }}</td>

                <td>ACTT</td>
                <td class="px-2">
                  <select class="w-full" name="" id="" v-model="job.status">
                    <option
                      v-for="option in availableStatus"
                      :value="option"
                      :key="job.jobNo+option"
                      @change="onStatusChange($event, job)"
                    >
                      {{ option }}
                    </option>
                  </select>
                </td>
                <td>{{job.lastUpdated}}</td>
                <td>36 mins</td>
                <td>30 mins</td>
                <td>MDW</td>
                <td>{{job.driver}}</td>
                <td>{{job.vehiclesStr}}</td>
                <td>{{job.pickupLocation}}</td>
                <td>{{job.dropoffLocation}}</td>
                <td class="actions">
                  <font-awesome-icon
                    title="Edit Job"
                    icon="edit"
                    class="ml-2"
                  />

                  <font-awesome-icon
                    title="Create Invoice"
                    icon="file-invoice-dollar"
                    class="ml-2"
                  />
                  <font-awesome-icon
                    title="Cancel Job"
                    icon="trash"
                    class="ml-2"
                  />

                  <font-awesome-icon
                    title="Take Payment"
                    icon="ellipsis-h"
                    class="ml-2"
                  />
                </td>
              </tr>
            </tbody>
          </table>
        </div>

      </div>
    </div>
    <assign-job-modal :isOpen="assignJobNo"></assign-job-modal>
  </div>
</template>

<script>
import AssignJobModal from './AssignJobModal.vue';
export default {
  components: { AssignJobModal },
  data() {
    return {
      assignJobNo:null,
      jobs: [
  {
    "id": 624,
    "accountId": 961,
    "jobTypeId": 13,
    "rateId": 12,
    "takenById": 4,
    "callerName": null,
    "callerPhone": null,
    "dateTaken": "2020-12-02T23:53:14.045737",
    "billToAccountId": 961,
    "description": null,
    "isCanceled": false,
    "isCancelled": false,
    "isQuote": false,
    "isSkippingDispatch": false,
    "referenceNumber": "",
    "jobEta": "2020-12-03T00:53:14.0457377",
    "oldJobNo": 335,
    "priority": 0,
    "phoneSearchable": "",
    "attachments": [],
    "jobAssignments": [
      {
        "id": 424,
        "employeeId": 4,
        "equipmentId": 14,
        "isCancelled": false,
        "isCleared": true,
        "isObsolete": false,
        "jobEvents": [
          {
            "id": 872,
            "eventDate": "2020-12-03T01:38:00",
            "name": "Cleared",
            "mileage": null,
            "impoundLotId": null,
            "noteId": null,
            "note": null,
            "order": 0
          },
          {
            "id": 870,
            "eventDate": "2020-12-03T01:37:42.8210461",
            "name": "Dispatch",
            "mileage": null,
            "impoundLotId": null,
            "noteId": null,
            "note": null,
            "order": 0
          }
        ]
      }
    ],
    "vehicles": [
      {
        "id": 597,
        "jobTargetOwners": [],
        "jobForms": [],
        "model": "PB105",
        "make": {
          "id": 140,
          "providerId": 64,
          "name": "IC CORPORATION",
          "isObsolete": false,
          "provider": null,
          "models": []
        },
        "year": "2013",
        "externalColor": "YELLOW",
        "internalColor": null,
        "vin": "4DRBUAAP8DB258335",
        "licensePlate": "",
        "licenseState": "",
        "ownerName": "",
        "isImpound": false,
        "isPoliceHold": false
      }
    ],
    "impoundEvents": [],
    "jobStops": [
      {
        "latitude": 37.0604863,
        "longitude": -93.31601839999999,
        "streetNumber": "1083",
        "street": "Kathryn St",
        "city": "Nixa",
        "state": "MO",
        "postalCode": "65714",
        "countryCode": "US",
        "nonGeoCodedAddress": null,
        "isNonGeoCodedAddress": false,
        "crossroads": "",
        "order": 1
      },
      {
        "latitude": 37.2492218,
        "longitude": -93.2417526,
        "streetNumber": "2635 E",
        "street": "Diamond St",
        "city": "Springfield",
        "state": "MO",
        "postalCode": "65803",
        "countryCode": "US",
        "nonGeoCodedAddress": null,
        "isNonGeoCodedAddress": false,
        "crossroads": "",
        "order": 2
      }
    ],
    "udf": [
      {
        "userDefinedFieldId": 7,
        "label": "truck1#",
        "value": "14",
        "isOnInvoice": true
      }
    ]
  },
  {
    "id": 625,
    "accountId": 9,
    "jobTypeId": 13,
    "rateId": 12,
    "takenById": 4,
    "callerName": null,
    "callerPhone": null,
    "dateTaken": "2020-12-03T01:32:27.2713461",
    "billToAccountId": 9,
    "description": "recovery",
    "isCanceled": false,
    "isCancelled": false,
    "isQuote": false,
    "isSkippingDispatch": false,
    "referenceNumber": "",
    "jobEta": "2020-12-03T02:32:27.2713465",
    "oldJobNo": 336,
    "priority": 0,
    "phoneSearchable": "",
    "attachments": [],
    "jobAssignments": [
      {
        "id": 423,
        "employeeId": 4,
        "equipmentId": 14,
        "isCancelled": false,
        "isCleared": true,
        "isObsolete": false,
        "jobEvents": [
          {
            "id": 871,
            "eventDate": "2020-12-03T01:38:00",
            "name": "Cleared",
            "mileage": null,
            "impoundLotId": null,
            "noteId": null,
            "note": null,
            "order": 0
          },
          {
            "id": 869,
            "eventDate": "2020-12-03T01:37:12.1467645",
            "name": "Dispatch",
            "mileage": null,
            "impoundLotId": null,
            "noteId": null,
            "note": null,
            "order": 0
          }
        ]
      }
    ],
    "vehicles": [],
    "impoundEvents": [],
    "jobStops": [
      {
        "latitude": 37.21917799999999,
        "longitude": -93.25000899999999,
        "streetNumber": "2331",
        "street": "E Pythian St",
        "city": "Springfield",
        "state": "MO",
        "postalCode": "65802",
        "countryCode": "US",
        "nonGeoCodedAddress": null,
        "isNonGeoCodedAddress": false,
        "crossroads": "",
        "order": 1
      }
    ],
    "udf": []
  },
  {
    "id": 631,
    "accountId": 20,
    "jobTypeId": 13,
    "rateId": 12,
    "takenById": 4,
    "callerName": null,
    "callerPhone": null,
    "dateTaken": "2020-12-04T16:52:54.6693975",
    "billToAccountId": 20,
    "description": null,
    "isCanceled": false,
    "isCancelled": false,
    "isQuote": false,
    "isSkippingDispatch": false,
    "referenceNumber": "",
    "jobEta": "2020-12-04T17:52:54.6693977",
    "oldJobNo": 337,
    "priority": 0,
    "phoneSearchable": "",
    "attachments": [],
    "jobAssignments": [
      {
        "id": 431,
        "employeeId": 4,
        "equipmentId": 14,
        "isCancelled": false,
        "isCleared": true,
        "isObsolete": false,
        "jobEvents": [
          {
            "id": 913,
            "eventDate": "2020-12-04T17:49:00",
            "name": "Cleared",
            "mileage": null,
            "impoundLotId": null,
            "noteId": null,
            "note": null,
            "order": 0
          },
          {
            "id": 903,
            "eventDate": "2020-12-04T17:14:42.0012796",
            "name": "Dispatch",
            "mileage": null,
            "impoundLotId": null,
            "noteId": null,
            "note": null,
            "order": 0
          }
        ]
      }
    ],
    "vehicles": [
      {
        "id": 599,
        "jobTargetOwners": [],
        "jobForms": [],
        "model": "SAVANA",
        "make": {
          "id": 57,
          "providerId": 64,
          "name": "GMC",
          "isObsolete": false,
          "provider": null,
          "models": []
        },
        "year": "2018",
        "externalColor": "",
        "internalColor": null,
        "vin": "1GD07RFP8J1901645",
        "licensePlate": "",
        "licenseState": "",
        "ownerName": "",
        "isImpound": false,
        "isPoliceHold": false
      }
    ],
    "impoundEvents": [],
    "jobStops": [
      {
        "latitude": 37.2422784,
        "longitude": -93.2420891,
        "streetNumber": "2526",
        "street": "N Neergard Ave",
        "city": "Springfield",
        "state": "MO",
        "postalCode": "65803",
        "countryCode": "US",
        "nonGeoCodedAddress": null,
        "isNonGeoCodedAddress": false,
        "crossroads": "",
        "order": 1
      },
      {
        "latitude": 37.1432678,
        "longitude": -93.267882,
        "streetNumber": "1555",
        "street": "E Independence St",
        "city": "Springfield",
        "state": "MO",
        "postalCode": "65804",
        "countryCode": "US",
        "nonGeoCodedAddress": null,
        "isNonGeoCodedAddress": false,
        "crossroads": "",
        "order": 2
      }
    ],
    "udf": [
      {
        "userDefinedFieldId": 7,
        "label": "truck1#",
        "value": "9123812",
        "isOnInvoice": true
      },
      {
        "userDefinedFieldId": 9,
        "label": "Odometer",
        "value": "68115",
        "isOnInvoice": true
      }
    ]
  },
  {
    "id": 632,
    "accountId": 50,
    "jobTypeId": 14,
    "rateId": 12,
    "takenById": 4,
    "callerName": null,
    "callerPhone": null,
    "dateTaken": "2020-12-04T17:13:00.4027801",
    "billToAccountId": 50,
    "description": null,
    "isCanceled": false,
    "isCancelled": true,
    "isQuote": false,
    "isSkippingDispatch": false,
    "referenceNumber": "",
    "jobEta": "2020-12-04T18:13:00.4027803",
    "oldJobNo": 338,
    "priority": 0,
    "phoneSearchable": "",
    "attachments": [],
    "jobAssignments": [
      {
        "id": 430,
        "employeeId": 4,
        "equipmentId": 14,
        "isCancelled": true,
        "isCleared": false,
        "isObsolete": false,
        "jobEvents": [
          {
            "id": 925,
            "eventDate": "2020-12-04T21:34:13.722257",
            "name": "Cancelled",
            "mileage": null,
            "impoundLotId": null,
            "noteId": 28,
            "note": null,
            "order": 0
          },
          {
            "id": 902,
            "eventDate": "2020-12-04T17:14:16.7551409",
            "name": "Dispatch",
            "mileage": null,
            "impoundLotId": null,
            "noteId": null,
            "note": null,
            "order": 0
          }
        ]
      }
    ],
    "vehicles": [
      {
        "id": 600,
        "jobTargetOwners": [],
        "jobForms": [],
        "model": "UNKNOWN",
        "make": {
          "id": 35,
          "providerId": 64,
          "name": "FORD",
          "isObsolete": false,
          "provider": null,
          "models": []
        },
        "year": "",
        "externalColor": "",
        "internalColor": null,
        "vin": "",
        "licensePlate": "",
        "licenseState": "",
        "ownerName": "",
        "isImpound": false,
        "isPoliceHold": false
      }
    ],
    "impoundEvents": [],
    "jobStops": [
      {
        "latitude": null,
        "longitude": null,
        "streetNumber": null,
        "street": null,
        "city": null,
        "state": null,
        "postalCode": null,
        "countryCode": null,
        "nonGeoCodedAddress": "5100 E  STATE HIGHTWAY OO STRAFFORD MO",
        "isNonGeoCodedAddress": true,
        "crossroads": "",
        "order": 1
      },
      {
        "latitude": 37.3476689,
        "longitude": -92.9065758,
        "streetNumber": "104",
        "street": "E Hubble Dr",
        "city": "Marshfield",
        "state": "MO",
        "postalCode": "65706",
        "countryCode": "US",
        "nonGeoCodedAddress": null,
        "isNonGeoCodedAddress": false,
        "crossroads": "",
        "order": 2
      }
    ],
    "udf": []
  },
  {
    "id": 633,
    "accountId": 9,
    "jobTypeId": 14,
    "rateId": 13,
    "takenById": 4,
    "callerName": null,
    "callerPhone": null,
    "dateTaken": "2020-12-04T17:59:58.8001189",
    "billToAccountId": 9,
    "description": null,
    "isCanceled": false,
    "isCancelled": false,
    "isQuote": false,
    "isSkippingDispatch": false,
    "referenceNumber": "",
    "jobEta": "2020-12-04T18:59:58.800119",
    "oldJobNo": 339,
    "priority": 0,
    "phoneSearchable": "",
    "attachments": [],
    "jobAssignments": [
      {
        "id": 433,
        "employeeId": 4,
        "equipmentId": 14,
        "isCancelled": false,
        "isCleared": true,
        "isObsolete": false,
        "jobEvents": [
          {
            "id": 928,
            "eventDate": "2020-12-06T22:20:00",
            "name": "Cleared",
            "mileage": null,
            "impoundLotId": null,
            "noteId": null,
            "note": null,
            "order": 0
          },
          {
            "id": 915,
            "eventDate": "2020-12-04T18:07:19.8243753",
            "name": "Dispatch",
            "mileage": null,
            "impoundLotId": null,
            "noteId": null,
            "note": null,
            "order": 0
          }
        ]
      }
    ],
    "vehicles": [
      {
        "id": 602,
        "jobTargetOwners": [],
        "jobForms": [],
        "model": "CALIBER",
        "make": {
          "id": 49,
          "providerId": 64,
          "name": "DODGE",
          "isObsolete": false,
          "provider": null,
          "models": []
        },
        "year": "2007",
        "externalColor": "BLACK",
        "internalColor": null,
        "vin": "1B3HB48B67D114728",
        "licensePlate": null,
        "licenseState": null,
        "ownerName": null,
        "isImpound": false,
        "isPoliceHold": false
      }
    ],
    "impoundEvents": [],
    "jobStops": [
      {
        "latitude": null,
        "longitude": null,
        "streetNumber": null,
        "street": null,
        "city": null,
        "state": null,
        "postalCode": null,
        "countryCode": null,
        "nonGeoCodedAddress": "State Highway 125, Strafford, MO, USA",
        "isNonGeoCodedAddress": true,
        "crossroads": "",
        "order": 1
      },
      {
        "latitude": 37.2684743,
        "longitude": -93.11935489999999,
        "streetNumber": "209",
        "street": "W Old Rte 66",
        "city": "Strafford",
        "state": "MO",
        "postalCode": "65757",
        "countryCode": "US",
        "nonGeoCodedAddress": null,
        "isNonGeoCodedAddress": false,
        "crossroads": "",
        "order": 2
      }
    ],
    "udf": []
  },
  {
    "id": 634,
    "accountId": 9,
    "jobTypeId": 14,
    "rateId": 13,
    "takenById": 4,
    "callerName": null,
    "callerPhone": null,
    "dateTaken": "2020-12-04T18:00:47.7358601",
    "billToAccountId": 9,
    "description": null,
    "isCanceled": false,
    "isCancelled": false,
    "isQuote": false,
    "isSkippingDispatch": false,
    "referenceNumber": "",
    "jobEta": "2020-12-04T19:00:47.7358602",
    "oldJobNo": 340,
    "priority": 0,
    "phoneSearchable": "",
    "attachments": [],
    "jobAssignments": [
      {
        "id": 432,
        "employeeId": 4,
        "equipmentId": 14,
        "isCancelled": false,
        "isCleared": true,
        "isObsolete": false,
        "jobEvents": [
          {
            "id": 929,
            "eventDate": "2020-12-06T22:20:00",
            "name": "Cleared",
            "mileage": null,
            "impoundLotId": null,
            "noteId": null,
            "note": null,
            "order": 0
          },
          {
            "id": 914,
            "eventDate": "2020-12-04T18:06:03.3765491",
            "name": "Dispatch",
            "mileage": null,
            "impoundLotId": null,
            "noteId": null,
            "note": null,
            "order": 0
          }
        ]
      }
    ],
    "vehicles": [
      {
        "id": 601,
        "jobTargetOwners": [],
        "jobForms": [],
        "model": "XTERRA",
        "make": {
          "id": 42,
          "providerId": 64,
          "name": "NISSAN",
          "isObsolete": false,
          "provider": null,
          "models": []
        },
        "year": "2002",
        "externalColor": "SILVER",
        "internalColor": null,
        "vin": null,
        "licensePlate": null,
        "licenseState": null,
        "ownerName": null,
        "isImpound": false,
        "isPoliceHold": false
      }
    ],
    "impoundEvents": [],
    "jobStops": [
      {
        "latitude": 37.1880471,
        "longitude": -93.24577219999999,
        "streetNumber": "2534",
        "street": "E Bennett St",
        "city": "Springfield",
        "state": "MO",
        "postalCode": "65804",
        "countryCode": "US",
        "nonGeoCodedAddress": "State Highway 125, Strafford, MO, USA",
        "isNonGeoCodedAddress": false,
        "crossroads": "",
        "order": 1
      },
      {
        "latitude": 37.3095167,
        "longitude": -93.26377339999999,
        "streetNumber": "1487",
        "street": "E Lelia Ln",
        "city": "Springfield",
        "state": "MO",
        "postalCode": "65803",
        "countryCode": "US",
        "nonGeoCodedAddress": null,
        "isNonGeoCodedAddress": false,
        "crossroads": "",
        "order": 2
      }
    ],
    "udf": []
  },
  {
    "id": 636,
    "accountId": 22,
    "jobTypeId": 15,
    "rateId": 12,
    "takenById": 4,
    "callerName": null,
    "callerPhone": null,
    "dateTaken": "2020-12-04T21:53:43.7451009",
    "billToAccountId": 22,
    "description": null,
    "isCanceled": false,
    "isCancelled": false,
    "isQuote": false,
    "isSkippingDispatch": false,
    "referenceNumber": "104341",
    "jobEta": "2020-12-04T22:53:43.745101",
    "oldJobNo": 341,
    "priority": 0,
    "phoneSearchable": "",
    "attachments": [],
    "jobAssignments": [
      {
        "id": 436,
        "employeeId": 4,
        "equipmentId": 14,
        "isCancelled": false,
        "isCleared": true,
        "isObsolete": false,
        "jobEvents": [
          {
            "id": 930,
            "eventDate": "2020-12-06T22:20:00",
            "name": "Cleared",
            "mileage": null,
            "impoundLotId": null,
            "noteId": null,
            "note": null,
            "order": 0
          },
          {
            "id": 927,
            "eventDate": "2020-12-06T22:19:55.27043",
            "name": "Dispatch",
            "mileage": null,
            "impoundLotId": null,
            "noteId": null,
            "note": null,
            "order": 0
          }
        ]
      }
    ],
    "vehicles": [
      {
        "id": 604,
        "jobTargetOwners": [],
        "jobForms": [],
        "model": "T680",
        "make": {
          "id": 44,
          "providerId": 64,
          "name": "KENWORTH",
          "isObsolete": false,
          "provider": null,
          "models": []
        },
        "year": "2019",
        "externalColor": "",
        "internalColor": null,
        "vin": "1XKYDP9X3KJ222534",
        "licensePlate": "",
        "licenseState": "",
        "ownerName": "",
        "isImpound": false,
        "isPoliceHold": false
      }
    ],
    "impoundEvents": [],
    "jobStops": [
      {
        "latitude": 37.2551312,
        "longitude": -93.1633381,
        "streetNumber": "3351",
        "street": "N Farm Rd 209",
        "city": "Strafford",
        "state": "MO",
        "postalCode": "65757",
        "countryCode": "US",
        "nonGeoCodedAddress": null,
        "isNonGeoCodedAddress": false,
        "crossroads": "",
        "order": 1
      },
      {
        "latitude": 37.2399139,
        "longitude": -93.2262726,
        "streetNumber": "3301",
        "street": "E Kearney St",
        "city": "Springfield",
        "state": "MO",
        "postalCode": "65803",
        "countryCode": "US",
        "nonGeoCodedAddress": null,
        "isNonGeoCodedAddress": false,
        "crossroads": "",
        "order": 2
      }
    ],
    "udf": [
      {
        "userDefinedFieldId": 7,
        "label": "truck1#",
        "value": "1793",
        "isOnInvoice": true
      }
    ]
  },
  {
    "id": 637,
    "accountId": 24,
    "jobTypeId": 15,
    "rateId": 12,
    "takenById": 4,
    "callerName": null,
    "callerPhone": null,
    "dateTaken": "2020-12-04T21:56:20.6804039",
    "billToAccountId": 24,
    "description": null,
    "isCanceled": false,
    "isCancelled": false,
    "isQuote": false,
    "isSkippingDispatch": false,
    "referenceNumber": "1112093530",
    "jobEta": "2020-12-04T22:56:20.680404",
    "oldJobNo": 342,
    "priority": 0,
    "phoneSearchable": "",
    "attachments": [],
    "jobAssignments": [
      {
        "id": 435,
        "employeeId": 4,
        "equipmentId": 14,
        "isCancelled": false,
        "isCleared": true,
        "isObsolete": false,
        "jobEvents": [
          {
            "id": 931,
            "eventDate": "2020-12-06T22:21:00",
            "name": "Cleared",
            "mileage": null,
            "impoundLotId": null,
            "noteId": null,
            "note": null,
            "order": 0
          },
          {
            "id": 932,
            "eventDate": "2020-12-06T22:21:00",
            "name": "Cleared",
            "mileage": null,
            "impoundLotId": null,
            "noteId": null,
            "note": null,
            "order": 0
          },
          {
            "id": 926,
            "eventDate": "2020-12-04T21:58:48.607506",
            "name": "Dispatch",
            "mileage": null,
            "impoundLotId": null,
            "noteId": null,
            "note": null,
            "order": 0
          }
        ]
      }
    ],
    "vehicles": [
      {
        "id": 605,
        "jobTargetOwners": [],
        "jobForms": [],
        "model": "VNL",
        "make": {
          "id": 141,
          "providerId": 64,
          "name": "VOLVO",
          "isObsolete": false,
          "provider": null,
          "models": []
        },
        "year": "2016",
        "externalColor": null,
        "internalColor": null,
        "vin": "4V4NC9EH7GN966749",
        "licensePlate": null,
        "licenseState": null,
        "ownerName": null,
        "isImpound": false,
        "isPoliceHold": false
      }
    ],
    "impoundEvents": [],
    "jobStops": [
      {
        "latitude": 37.240147,
        "longitude": -93.2009659,
        "streetNumber": "4500",
        "street": "E Progress Pl",
        "city": "Springfield",
        "state": "MO",
        "postalCode": "65803",
        "countryCode": "US",
        "nonGeoCodedAddress": null,
        "isNonGeoCodedAddress": false,
        "crossroads": "",
        "order": 1
      },
      {
        "latitude": 37.2097552,
        "longitude": -93.2474809,
        "streetNumber": "2412",
        "street": "E Chestnut Expy",
        "city": "Springfield",
        "state": "MO",
        "postalCode": "65802",
        "countryCode": "US",
        "nonGeoCodedAddress": null,
        "isNonGeoCodedAddress": false,
        "crossroads": "",
        "order": 2
      }
    ],
    "udf": [
      {
        "userDefinedFieldId": 7,
        "label": "truck1#",
        "value": "656534",
        "isOnInvoice": true
      }
    ]
  },
  {
    "id": 638,
    "accountId": 9,
    "jobTypeId": 13,
    "rateId": 12,
    "takenById": 4,
    "callerName": null,
    "callerPhone": null,
    "dateTaken": "2020-12-06T22:25:52.3751707",
    "billToAccountId": 9,
    "description": "jump start",
    "isCanceled": false,
    "isCancelled": false,
    "isQuote": false,
    "isSkippingDispatch": false,
    "referenceNumber": "",
    "jobEta": "2020-12-06T23:25:52.3751713",
    "oldJobNo": 343,
    "priority": 0,
    "phoneSearchable": "",
    "attachments": [],
    "jobAssignments": [
      {
        "id": 437,
        "employeeId": 4,
        "equipmentId": 14,
        "isCancelled": false,
        "isCleared": true,
        "isObsolete": false,
        "jobEvents": [
          {
            "id": 935,
            "eventDate": "2020-12-06T22:32:00",
            "name": "Cleared",
            "mileage": null,
            "impoundLotId": null,
            "noteId": null,
            "note": null,
            "order": 0
          },
          {
            "id": 933,
            "eventDate": "2020-12-06T22:31:13.3944679",
            "name": "Dispatch",
            "mileage": null,
            "impoundLotId": null,
            "noteId": null,
            "note": null,
            "order": 0
          }
        ]
      }
    ],
    "vehicles": [],
    "impoundEvents": [],
    "jobStops": [
      {
        "latitude": 37.27594159999999,
        "longitude": -93.111829,
        "streetNumber": null,
        "street": "MO-125",
        "city": "Strafford",
        "state": "MO",
        "postalCode": "65757",
        "countryCode": "US",
        "nonGeoCodedAddress": null,
        "isNonGeoCodedAddress": false,
        "crossroads": "",
        "order": 1
      }
    ],
    "udf": []
  },
  {
    "id": 639,
    "accountId": 28,
    "jobTypeId": 13,
    "rateId": 12,
    "takenById": 4,
    "callerName": null,
    "callerPhone": null,
    "dateTaken": "2020-12-06T22:30:32.268044",
    "billToAccountId": 28,
    "description": "jump start",
    "isCanceled": false,
    "isCancelled": false,
    "isQuote": false,
    "isSkippingDispatch": false,
    "referenceNumber": "334-001016G",
    "jobEta": "2020-12-06T23:30:32.2680449",
    "oldJobNo": 344,
    "priority": 0,
    "phoneSearchable": "",
    "attachments": [],
    "jobAssignments": [
      {
        "id": 438,
        "employeeId": 4,
        "equipmentId": 14,
        "isCancelled": false,
        "isCleared": true,
        "isObsolete": false,
        "jobEvents": [
          {
            "id": 936,
            "eventDate": "2020-12-06T22:39:00",
            "name": "Cleared",
            "mileage": null,
            "impoundLotId": null,
            "noteId": null,
            "note": null,
            "order": 0
          },
          {
            "id": 934,
            "eventDate": "2020-12-06T22:31:39.7326809",
            "name": "Dispatch",
            "mileage": null,
            "impoundLotId": null,
            "noteId": null,
            "note": null,
            "order": 0
          }
        ]
      }
    ],
    "vehicles": [
      {
        "id": 606,
        "jobTargetOwners": [],
        "jobForms": [],
        "model": "E-450 SUPER DUTY",
        "make": {
          "id": 35,
          "providerId": 64,
          "name": "FORD",
          "isObsolete": false,
          "provider": null,
          "models": []
        },
        "year": "2011",
        "externalColor": "",
        "internalColor": null,
        "vin": "1FDXE4FS6BDA50618",
        "licensePlate": "",
        "licenseState": "",
        "ownerName": "",
        "isImpound": false,
        "isPoliceHold": false
      }
    ],
    "impoundEvents": [],
    "jobStops": [
      {
        "latitude": 37.2051753,
        "longitude": -93.2615797,
        "streetNumber": "440",
        "street": "S Glenstone Ave",
        "city": "Springfield",
        "state": "MO",
        "postalCode": "65802",
        "countryCode": "US",
        "nonGeoCodedAddress": null,
        "isNonGeoCodedAddress": false,
        "crossroads": "",
        "order": 1
      }
    ],
    "udf": [
      {
        "userDefinedFieldId": 7,
        "label": "truck1#",
        "value": "TT3790D",
        "isOnInvoice": true
      },
      {
        "userDefinedFieldId": 9,
        "label": "Odometer",
        "value": "98872",
        "isOnInvoice": true
      }
    ]
  }
]



,
      availableStatus: [
        "Unassigned",
        "Dispatch",
        "En-Route",
        "Arrived",
        "Hooked",
        "Dropped",
        "Completed",
          "Cleared",
        "Cancelled"
      ],
    };
  },
  methods: {
      startDrag(event){
          console.log(event);
      },
      onDrop(event,id){
          console.log(event,id);
      },
      onStatusChange(event, job){
          console.log(event,job);
          alert('test');
      },
    formatJobStopLocation(jobStop) {
      return jobStop.isNonGeoCodedAddress ? jobStop.nonGeoCodedAddress : `${jobStop.streetNumber || ''} ${jobStop.street} ${jobStop.city}, ${jobStop.state} ${jobStop.postalCode} ${jobStop.countryCode} `;
    },
    formatJobTargets(vehicles){
        let result = '';
        if(vehicles.length > 0)
        {
            for (let i = 0; i < vehicles.length; i++) {
                const v = vehicles[i];
                result += v.year + ' ' + v.make.name + ' ' + v.model
                if(i+1 != vehicles.length){
                    result += ", ";
                }
            }
        }
        return result;
    }
  },
  computed: {
      activeJobs() {
          let unassignedJobs = this.jobs.filter((j) => j.jobAssignments?.length == 0);
          let result = [...unassignedJobs];

          for (var i = 0; i < this.jobs.length; i++) {
              let j = this.jobs[i];
              if (j.jobAssignments.length > 0) {
                  for (var k = 0; k < j.jobAssignments.length; k++) {

                      result.push(
                           {
                              jobNo: j.oldJobNo,
                              accountName: 'ABC',
                              status: j.jobAssignments[k].jobEvents[0].name,
                              lastUpdated: j.jobAssignments[k].jobEvents[0].eventDate,
                              towType: "",
                              driver: j.jobAssignments[k].employeeId ||  "Unassigned",
                              vehiclesStr: this.formatJobTargets(j.vehicles),
                              pickupLocation:
                                  j.jobStops.length > 0
                                      ? this.formatJobStopLocation(j.jobStops[0])
                                      : "NA",
                              dropoffLocation:
                                  j.jobStops.length > 1
                                      ? this.formatJobStopLocation(j.jobStops[j.jobStops.length - 1])
                                      : "NA",
                          }
                      );
                  }

              } else {
                  result.push(
                       {
                          jobNo: j.oldJobNo,
                          accountName: 'ABC',
                          status: "Unassigned",
                          lastUpdated: j.dateTaken,
                          towType: "",
                          driver: "Unassigned",
                          vehiclesStr: this.formatJobTargets(j.vehicles),
                          pickupLocation:
                              j.jobStops.length > 0
                                  ? this.formatJobStopLocation(j.jobStops[0])
                                  : "NA",
                          dropoffLocation:
                              j.jobStops.length > 1
                                  ? this.formatJobStopLocation(j.jobStops[j.jobStops.length - 1])
                                  : "NA",
                      }
                  );
              }
          }


          return result;
    },
  },
};
</script>

<style>
ul {
  padding-top: 2px;
}
td {
  text-align: center;
}
li {
  margin-bottom: 4px;
  margin-right: 2px;
  padding-left: 3px;
  border: #999 1px solid;
  cursor: grab;
}
li:focus{
    cursor: grabbing;
}
li p:first-child{
    font-weight: bold;
    font-size: small;

}
li p:last-child{
    font-size: smaller;

}

li.online {
  background-color:#f4742480;
  color:#413f3f;
}
li.offline {
  background-color:#95959560;
  color:#95959580;
}

label {
  padding: 0;
  margin: 0;
}

/* select {
  height: 2em;
  border: 1px solid #969595;
  padding: 5px;
} */

button:focus,
button:active {
  outline: none;
  outline: 0;
}
button:hover {
  -webkit-box-shadow: -5px 5px 0px -2px rgba(0, 0, 0, 0.58);
  -moz-box-shadow: -5px 5px 0px -2px rgba(0, 0, 0, 0.58);
  box-shadow: -5px 5px 0px -2px rgba(0, 0, 0, 0.58);
}
button:active {
  -webkit-box-shadow: inset -5px -5px 5px -2px rgba(0, 0, 0, 0.58);
  -moz-box-shadow: inset -5px -5px 5px -2px rgba(0, 0, 0, 0.58);
  box-shadow: inset -5px -5px 5px -2px rgba(0, 0, 0, 0.58);
}
button:active {
  -webkit-box-shadow: -5px -5px 5px -2px rgba(0, 0, 0, 0.58);
  -moz-box-shadow: -5px -5px 5px -2px rgba(0, 0, 0, 0.58);
  box-shadow: -5px -5px 5px -2px rgba(0, 0, 0, 0.58);
}
*:focus {
  outline: none;
}
.btn {
  color: #18a2cf;
  background-color: #fff;
  font-weight: 700;
  padding: 15px 25px;
  text-align: center;
  cursor: pointer;
  outline: none;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
  border-bottom: 2px solid transparent;
  border-left: 1px solid transparent;
}
.btn:hover {
  background-color: white;
  color: #18a2cf;
  /* border-bottom:2px solid black; */
  border-left: 1px solid #969595;
  border-bottom: 1px solid #969595;
}

.btn:active {
  background-color: white;
  color: #18a2cf;
  box-shadow: none;

  transform: translateY(4px) translateX(-4px);
}

.bg-tracker-blue {
  background-color: #18a2cf;
}
.text-tracker-orange {
  color: #f47424;
}
.btn {
  padding-left: 1.5rem;
  padding-right: 1.5rem;
  padding-top: 0.75rem;
  padding-bottom: 0.75rem;
  border-radius: 0.25rem;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.12), 0 2px 4px 0 rgba(0, 0, 0, 0.08);
  width: auto;
}

.btn:hover {
  background-color: white;
  color: #18a2cf;
  /* border-bottom:2px solid black; */
  border-left: 1px solid #969595;
  border-bottom: 1px solid #969595;
}

.btn:active {
  background-color: white;
  color: #18a2cf;
  box-shadow: none;

  transform: translateY(4px) translateX(-4px);
}
/* The switch - the box around the slider */
.switch {
  position: relative;
  display: inline-block;
  width: 40px;
  height: 24px;
}
/* Hide default HTML checkbox */
.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}
/* The slider */
.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: 0.4s;
  transition: 0.4s;
}
.slider:before {
  position: absolute;
  content: "";
  height: 16px;
  width: 16px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: 0.4s;
  transition: 0.4s;
}
input:checked + .slider {
  background-color: #2196f3;
}
input:focus + .slider {
  box-shadow: 0 0 1px #2196f3;
}
input:checked + .slider:before {
  -webkit-transform: translateX(16px);
  -ms-transform: translateX(16px);
  transform: translateX(16px);
}
/* Rounded sliders */
.slider.round {
  border-radius: 24px;
}
.slider.round:before {
  border-radius: 50%;
}
.border-tracker-blue {
  background-color: #18a2cf;
}
.border-tracker-blue input {
  font-weight: bold;
}

.inactive-item,
.inactive-item input {
  background-color: gray;
  text-decoration: line-through;
}
label {
  display: block;
}
.searchItem {
  height: 2em;
  border: 1px solid #969595;
}
.active-item td {
  height: 37px;
}
.tracker-border-gray {
  border: 1px solid #969595;
}

.form-input,
.form-select {
  display: block;
  height: 2rem;
  padding: 0.25rem;
  width: 100%;
  border-width: 1px;
  border-radius: 0.25rem;
  font-size: 0.875rem;
  line-height: 1;
  background-color: #fcfcfc;
  border-color: #e2e8f0;
}
.driverList {
  overflow-y: scroll;
  scrollbar-width: thin;
}
::-webkit-scrollbar-track {
  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
  border-radius: 10px;
  background-color: #f5f5f5;
  overflow-x: auto;
}

::-webkit-scrollbar {
  width: 6px;
  height: 6px;
  background-color: #f5f5f5;
  overflow-x: auto;
}

::-webkit-scrollbar-thumb {
  border-radius: 10px;
  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
  background-color: #18a2cf;
  overflow-x: auto;
}
.input-group {
  margin-left: 2px;
  margin-right: 2px;
  min-width: 200px;
}
.input-group label {
  color: white;
}
.input-group input {
  height: 32px;
}
.jobTable tbody tr {
  height: 60px;
}
.jobTable tbody {
  margin-bottom: 30px;
}
.bg-tracker-orange-light {
  background-color: #ff9b29;
}
.jobTable tbody td {
  border-top: 1px solid #969595;
  border-bottom: 1px solid #969595;
font-size: smaller;
}
.jobTable tbody tr td:first-child {
  border: 1px solid #969595;
}
.jobTable tbody tr td:last-child {
  border-right: 1px solid #969595;
}
.jobTable thead th {
  border-top: 1px solid #969595;
  border-bottom: 1px solid #969595;
font-size: small;
}
.jobTable thead tr th:first-child {
  border: 1px solid #969595;
}
.jobTable thead tr th:last-child {
  border-right: 1px solid #969595;
}
.jobTable tbody tr:nth-child(even) {background-color: #f2f2f2;}


th {
  text-align: center;
  vertical-align: bottom;
  padding: 5px;
}
.actions svg {
  cursor: pointer;
}
svg {
  color: #969595;
}
svg:hover {
  color: rgb(34, 34, 34);
}
</style>