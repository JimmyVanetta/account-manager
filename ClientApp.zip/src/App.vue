<template>
  <div id="app" class="bg-gray-200 h-screen">
    <div class="bg-white h-screen">
      <div class="flex h-full">
        <div
          class="bg-gray-200 w-full flex-row items-start justify-center"
          style="
            background-image: url('https://trackerbrbdevtest.azurewebsites.net/assets/img/bg-main-25.f362dce4.png');
            background-repeat: none;
          "
        >
          <div
            class="h-18 py-2 w-full whitespace-no-wrap leading-none bg-white shadow-md md:p-3 flex justify-between items-center"
          >
            <img
              class="w-48"
              src="https://trackerbrbdevtest.azurewebsites.net/assets/img/tracker-TMS-orange-grey.7bb94995.png"
            />
          </div>
          <div class="flex" style="height: 91vh; overflow-y: auto">
            <div
              class="flex px-2 py-3 pb-4 w-48 bg-white shadow flex-col justify-between items-center h-full"
            >
              <div>
                <button
                  class="btn mx-auto"
                  style="width: 100%; border: 1px solid #969595"
                  v-shortkey="['alt', 'n']"
                  @shortkey="showJobModal = true"
                  @click="showJobModal = true"
                >
                  <i class="fa fa-plus pr-2"></i><u>N</u>ew Call
                </button>
                <a
                  href="#"
                  class="block py-1 text mt-1 text-dark-gray font-semibold px-2"
                  ><i class="fa fa-tachometer px-2"></i>Dashboard</a
                >
                <div v-shortkey="['alt', 'g']" @shortkey="$router.push('/Grid')">
                  <router-link
                    to="/Grid"
                    class="block py-1 text mt-1 text-dark-gray font-semibold px-2"
                  >
                    <i class="fa fa-calendar px-2"></i><u>G</u>rid
                  </router-link>
                </div>

                <router-link
                  to="/Accounts"
                  class="block py-1 text mt-1 text-dark-gray font-semibold px-2"
                >
                  <i class="fa fa-book px-2"></i>Accounts
                </router-link>
                <router-link
                  to="/Maps"
                  class="block py-1 text mt-1 text-dark-gray font-semibold px-2"
                >
                  <i class="fa fa-map px-2"></i>Maps
                </router-link>
                <a
                  href="#"
                  class="block py-1 text mt-1 text-dark-gray font-semibold px-2"
                >
                  <i class="fa fa-pie-chart px-2"></i>Reports</a
                >
                <a
                  href="#"
                  class="block py-1 text mt-1 text-dark-gray font-semibold px-2"
                >
                  <i class="fa fa-users px-2"></i>Employees</a
                >
              </div>
              <div class="w-full px-2">
                <div class="flex justify-between">
                  <router-link
                    to="/foo"
                    class="icon text-tracker-grey hover:text-tracker-grey-dark hover:bg-gray-300 rounded-full p-2 no-underline cursor-pointer"
                  >
                    <i class="fa fa-history"></i
                  ></router-link>
                  <a
                    class="icon text-tracker-grey hover:text-tracker-grey-dark hover:bg-gray-300 rounded-full p-2 no-underline cursor-pointer"
                    ><i class="fa fa-comments"></i
                  ></a>
                  <a
                    class="icon text-tracker-grey hover:text-tracker-grey-dark hover:bg-gray-300 rounded-full p-2 no-underline cursor-pointer"
                    ><i class="fa fa-envelope"></i
                  ></a>
                  <router-link
                    to="/rates"
                    class="icon text-tracker-grey hover:text-tracker-grey-dark hover:bg-gray-300 rounded-full p-2 no-underline cursor-pointer"
                    ><i class="fa fa-gear"></i
                  ></router-link>
                </div>
              </div>
              <!-- <hr class="text-white"/> -->
            </div>
            <router-view></router-view>
          </div>
        </div>
      </div>
    </div>
    <NewJobModal
      :isOpen="showJobModal"
      @onCloseModal="closeModal"
    ></NewJobModal>
  </div>
</template>

<script>
import NewJobModal from "./views/NewJobModal.vue";

export default {
  name: "App",
  components: {
    NewJobModal,
  },
  data() {
    return {
      showJobModal: false,
    };
  },
  methods: {
    closeModal() {
      console.log("test");
      this.showJobModal = false;
    },
  },
  mounted() {
    console.log(process.env.VUE_APP_GOOGLE_APIKEY);
  },
  async created() {
    this.$store.dispatch("accounts/getAllAccounts");
    this.$store.dispatch("rates/getAllRates");
    this.$store.dispatch("itemRates/getAllItemRates");
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
}
</style>
