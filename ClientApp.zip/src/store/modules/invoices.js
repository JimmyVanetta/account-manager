import api from '../../api/Invoices'

// initial state
const state = () => ({
  all: []
})

// getters
const getters = {}

// actions
const actions = {
    getAllAccounts ({ commit }) {
    api.getAllInvoices(accounts => {
      commit('setInvoices', accounts)
    })
  }
}

// mutations
const mutations = {
    setInvoices (state, accounts) {
    state.all = accounts
  },

}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
