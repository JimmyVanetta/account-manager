import api from '../../api/Rates'

// initial state
const state = () => ({
  all: []
})

// getters
const getters = {}

// actions
const actions = {
    getAllRates ({ commit }) {
    return api.getAllRates().then(accounts => {
      console.log(accounts);
      commit('setRates', accounts)
      return accounts;
    });
  }
}

// mutations
const mutations = {
    setRates (state, accounts) {
    state.all = accounts
  },

}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
