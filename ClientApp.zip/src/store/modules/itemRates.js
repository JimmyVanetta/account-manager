import api from '../../api/itemRates'

// initial state
const state = () => ({
    all: []
})

// getters
const getters = {

}

// actions
const actions = {
    getAllItemRates({ commit }) {
        api.getAllItemRates(accounts => {
            commit('setItemRates', accounts)
        })
    },
    addStepRate({ commit }, { selectedItem, selectedAccount, selectedRate, selectedJobType }) {
        console.log(selectedItem, selectedAccount, selectedRate, selectedJobType);

        const rateItems = selectedItem.itemRates.filter(
            (r) =>
                r.jobTypeId == selectedJobType.jobTypeId &&
                r.accountId == selectedAccount &&
                r.rateId == selectedRate
        );

        rateItems.sort((a, b) => {
            if (a.amount < b.amount) {
                return -1;
            }
            if (a.amount > b.amount) {
                return 1;
            }
            return 0;
        });
        const itemRate = {
            accountId: selectedAccount,
            amount: 0,
            isDirty: true,
            jobTypeId: selectedJobType.jobTypeId,
            rateId: selectedRate,
            priority: rateItems[rateItems.length - 1] ? rateItems[rateItems.length - 1].priority + 1 : 0,
            tierCount: 1
        }
        commit('addStep', { selectedItem: selectedItem, itemRate: itemRate });
    },
    updateTierRate({ commit }, { amt, itemCode, jobType, selectedAccount, selectedRate, tierCount, priority }) {
        commit('setItemJobRateTier', { jobType: jobType, itemCode: itemCode, selectedAccount: selectedAccount, selectedRate: selectedRate, amount: amt, tierCount, priority });

    },
    copyItemRates({ commit }, { itemCode, jobTypeId, selectedAccountId, selectedRateId, newRates }) {
        commit('setItemNewRates', { itemCode, jobTypeId, selectedAccountId, selectedRateId, newRates });
    },
    updateFlatRate({ commit }, { amt, item, jobType, selectedAccount, selectedRate }) {

        commit('setItemJobRate', { selectedItem: item, jobType: jobType, selectedAccount: selectedAccount, selectedRate: selectedRate, amount: amt });




    }
}

// mutations
const mutations = {
    setItemRates(state, itemRates) {
        state.all = itemRates
    },
    setItemNewRates(state, { itemCode, jobTypeId, selectedAccountId, selectedRateId, newRates }) {
        let newState = [...state.all];
        for (let i = 0; i < newState.length; i++) {
            const item = newState[i];
            if (item.itemCode === itemCode) {
                let dd = [];
                dd = item.itemRates.filter((r) => r.jobTypeId != jobTypeId && r.accountId == selectedAccountId && r.rateId == selectedRateId);
                item.itemRates = [...dd,...newRates];
                break;
            }

        }
        state.all = newState;
    },
    addStep(state, { selectedItem, itemRate }) {
        let newState = [...state.all];
        for (let i = 0; i < newState.length; i++) {
            const item = newState[i];
            if (item.itemCode === selectedItem.itemCode) {
                newState[i].itemRates.push(itemRate);
                break;
            }

        }
        state.all = newState;
    },
    setItemJobRateTier(state, { itemCode, jobType, selectedAccount, selectedRate, amount, tierCount, priority }) {
        for (let i = 0; i < state.all.length; i++) {
            const item = state.all[i];
            if (item.itemCode === itemCode) {
                for (let j = 0; j < item.itemRates.length; j++) {
                    const itemRate = item.itemRates[j];
                    if (itemRate.jobTypeId == jobType.jobTypeId && itemRate.accountId == selectedAccount && itemRate.rateId == selectedRate && itemRate.priority == priority) {
                        let isDirty = state.all[i].itemRates[j].isDirty;
                        state.all[i].itemRates[j].isDirty = isDirty || (state.all[i].itemRates[j].amount != amount);
                        state.all[i].isDirty = isDirty || (state.all[i].itemRates[j].amount != amount);

                        state.all[i].itemRates[j].tierCount = tierCount;
                        state.all[i].itemRates[j].amount = amount;
                        console.log('found');
                        break;
                    }
                }
                break;
            }

        }
    },
    setItemJobRate(state, { selectedItem, jobType, selectedAccount, selectedRate, amount }) {

        for (let i = 0; i < state.all.length; i++) {
            const item = state.all[i];
            if (item.itemCode === selectedItem.itemCode) {
                for (let j = 0; j < item.itemRates.length; j++) {
                    const itemRate = item.itemRates[j];
                    if (itemRate.jobTypeId == jobType.jobTypeId && itemRate.accountId == selectedAccount && itemRate.rateId == selectedRate) {
                        let isDirty = state.all[i].itemRates[j].isDirty;
                        state.all[i].itemRates[j].isDirty = isDirty || (state.all[i].itemRates[j].amount != amount);
                        state.all[i].isDirty = isDirty || (state.all[i].itemRates[j].amount != amount);
                        state.all[i].itemRates[j].amount = amount;
                        console.log('found');
                        break;
                    }
                }
                break;
            }

        }
        // let newState = [... state.all];
        // for (let i = 0; i < newState.length; i++) {
        //     const item = newState[i];
        //     if(item.itemCode === update.jobItem.itemCode){
        //         let rateItem = [... item.itemRates.filter(
        //             (r) =>
        //               r.jobTypeId == update.jobType.jobTypeId &&
        //               r.accountId == update.selectedAccount &&
        //               r.rateId == update.selectedRate &&
        //               r.priority === 0
        //           )][0];
        //           if (rateItem && rateItem.amount != update.amt) {
        //             item.isDirty = true;
        //             rateItem.isDirty = true;
        //             rateItem.amount = update.amt;
        //           }

        //         //newState[i] = rateItem;
        //         break;
        //     }

        // }
        //state.all = newState;
    },
    toggleActiveItem(state,item){
        let newState = [...state.all];
        for (let i = 0; i < newState.length; i++) {
            if (newState[i].itemCode === item.itemCode) {
                newState[i].isDirty = true;
                newState[i].isObsolete = !newState[i].isObsolete
                break;
            }

        }
        state.all = newState;
    }


}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}
