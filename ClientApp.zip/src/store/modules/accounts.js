import api from '../../api/Accounts'

// initial state
const state = () => ({
  all: []
})

// getters
const getters = {}

// actions
const actions = {
    getAllAccounts ({ commit }) {
    api.getAllAccounts(accounts => {
      commit('setAccounts', accounts)
    })
  }
}

// mutations
const mutations = {
    setAccounts (state, accounts) {
    state.all = accounts
  },

}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
