import Vue from 'vue'
import Vuex from 'vuex'
import accounts from './modules/accounts'
import rates from './modules/rates'
import itemRates from './modules/itemRates'
import VueHotkey from 'v-hotkey'

Vue.use(VueHotkey)

//Vue.use(require('vue-shortkey'))
Vue.use(Vuex)

const debug = process.env.NODE_ENV !== 'production'

export default new Vuex.Store({
  modules: {
    accounts,
    rates,
    itemRates
  },
  strict: debug,
})
