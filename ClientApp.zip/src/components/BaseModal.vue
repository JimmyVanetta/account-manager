<template>
    <div>
        <div v-if="showModal"
             class="overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none justify-center items-center flex">
            <div class="relative w-auto my-24 mx-auto self-start">
                <!--content-->
                <div class="border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-white outline-none focus:outline-none" :class="{ large: size == 'large', small: size == 'small'}" >
                    <!--header-->
                    <div class="flex items-start justify-around p-5 border-b border-solid border-gray-300 rounded-t bg-tracker-blue ">
                        <h3 class="text-3xl font-semibold flex-1 text-left text-white">
                            {{ title }}
                        </h3>
                        <button v-for="action in actions" :key="action.btnId"
                                class="btn  mx-2"
                                type="button"
                                style="transition: all 0.15s ease"
                                v-shortkey="action.shortkey" @shortkey="action.callback"
                                v-on:click="action.callback"
                                v-html="action.Text"
                                >
                        </button>
                        <button class=" btn"
                                type="button"
                                style="transition: all 0.15s ease"
                                v-on:click="toggleModal()"
                                v-shortkey="['esc']"
                                @shortkey="toggleModal">
                            Close
                        </button>
                    </div>
                    <!--body-->
                    <div class="relative p-6 flex-auto">
                        <slot />
                    </div>
                    <!--footer-->
                    <!-- <div
                      class="flex items-center justify-end p-6 border-t border-solid border-gray-300 rounded-b"
                    >

                    </div> -->
                </div>
            </div>
        </div>
        <div v-if="showModal" class="opacity-75 fixed inset-0 z-40 bg-black"></div>
    </div>
</template>
<script>
    export default {
        name: "regular-modal",
        props: {
            showModal: Boolean,
            title: String,
            actions: Array,
            size: String,
        },
        // data() {
        //   return {
        //     showModal: false
        //   }
        // },
        methods: {
            toggleModal() {
                this.$emit("onCloseModal");
            },
        },

    };
</script>
<style>
    .large {
        width: 170vh
    }

    .small {
        width: 70vh
    }
</style>