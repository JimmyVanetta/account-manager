<script>
export default {
    props:{
        lat:{type:Number, required: true},
        lng:{type:Number, required: true},
    },
    data: () => ({
        marker: null
    }),
    mounted() {
        this.$parent.getMap(map => {
            this.marker = new window.google.maps.Marker({
                position: {lat: this.lat, lng: this.lng},
                map: map
            });
        });
    },
    beforeDestroy() {
        this.marker.setMap(null);
        if(window.google.maps.events)
        window.google.maps.events.clearInstanceListeners(this.marker);
        
    },
    render() {
        return null;
    }
}
</script>