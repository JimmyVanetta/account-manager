<template>
    <div class="mx-3 mt-3 flex-no-wrap w-full">
        <div class="">
            <div class="py-2 p-4 rounded-t flex items-center justify-between bg-tracker-blue shadow-md border-l border-r border-t border-black">
                <h1 class="text-white font-bold text-xl">Rate Setup</h1>
                <div>
                    <button class="btn mx-2" @click="handleAddItem">
                        New <u>I</u>tem
                    </button>
                    <button class="btn mx-2">New <u>R</u>ate</button>
                    <button class="btn mx-2">New <u>A</u>ccount</button>
                    <button class="btn mx-2"
                            v-hotkey.stop="{
      'c': handleSaveClick,
    }"
                            @click="() => {showAddJobTypeDialog = true}"
                           >
                        New <u>J</u>obType
                    </button>
                    <button class="btn mx-2"
                            :class="{ 'text-tracker-orange': getDirtyStatus }"
                             v-hotkey.stop="{
      'c': handleSaveOtherClick,
    }"
                            @click="() => {showAddJobTypeDialog = true}"

                            >
                        <i class="fa pr-2 fa-save"></i><u>S</u>ave
                    </button>
                </div>
            </div>
            <div class="" style="max-height: 80vh; overflow-y: auto">
                <table style="width: 100%"
                       class="bg-white shadow-md rounded border tracker-border-gray rateTable">
                    <thead>
                        <tr>
                            <th colspan="7"
                                style="pl-2; text-align: left; border:1px solid #969595; ">
                                <div class="flex justify-around">
                                    <div class="px-2 w-40 flex-1">
                                        <label for="rate" class="flex justify-between">
                                            <span>Account:</span><span class="fa fa-edit text-right"
                                                                       aria-hidden="true"></span>
                                        </label>
                                        <select class="w-full"
                                                v-model="selectedAccount"
                                                name="account"
                                                id="{account.accountId + '-accountOption'} ">
                                            <option v-for="account in accounts"
                                                    :key="account.accountId"
                                                    :value="account.accountId">
                                                {{ account.accountName }}
                                            </option>
                                        </select>
                                    </div>
                                    <div class="px-2 w-40 flex-1">
                                        <label for="rate" class="flex justify-between">
                                            <span>Rate:</span><span class="fa fa-edit text-right"
                                                                    aria-hidden="true"></span>
                                        </label>
                                        <select class="w-full"
                                                v-model="selectedRate"
                                                name="rate"
                                                id="{rate.rateId + '-rateOption'}">
                                            <option v-for="(rate, index) in rates"
                                                    v-bind:value="rate.rateId"
                                                    v-bind:selected="index === 0 || rate.rateId == selectedRate"
                                                    :key="rate.rateId">
                                                {{ rate.rateName }}
                                            </option>
                                        </select>
                                    </div>

                                    <div class="px-2 w-40 flex-1">
                                        <label class="" for="rate">Filter Item:</label>
                                        <input text=""
                                               v-model="itemFilter"
                                               class="form-item w-full border searchItem" />
                                    </div>
                                </div>
                            </th>
                            <th style="text-align: center; border: 1px solid #969595"
                                :colspan="jobTypes.length + 2">
                                <div class="flex justify-between items-center" style="padding-left: 2em;padding-right: 2em;">
                                    <!-- <button class="btn">Clear Steps</button> -->
                                    <div>
                                        <label style="text-align:left">Job Types</label><input type="text"
                                                                                               style="width: 19em; border: 1px solid #969595" />
                                    </div>
                                    <button class="btn" @click="openDialog()">Add Steps</button>
                                </div>
                            </th>
                        </tr>
                        <tr>
                            <th></th>
                            <th class="pl-2" style="padding-left: 0.75rem">Code</th>
                            <th style="width: 15em">Name</th>
                            <th style="width: 30em">Item Description</th>
                            <th style="width: 62px">Taxable</th>
                            <th style="width: 4em">Tax 1</th>
                            <th style="width: 4em">Tax 2</th>
                            <th style="
                    text-align: right;
                    border: 1px solid #969595;
                    width: 2em;
                  ">
                                <span class="fa fa-chevron-left"
                                      aria-hidden="true"
                                      v-if="startIndex > 0"
                                      @click="startIndex--"></span>
                            </th>
                            <th class="jobTypeColumn"
                                style="border: 1px solid #969595"
                                v-for="jobType in filteredJobTypes"
                                :key="`${jobType.shortCode}-Header`">
                                <div class="flex justify-between items-center">
                                    <span class="text-left" :title="jobType.jobTypeName">
                                        {{ jobType.shortCode }}
                                    </span>
                                    <span class="fa fa-edit text-right"
                                          aria-hidden="true"></span>
                                </div>
                            </th>
                            <th style="
                    text-align: right;
                    border: 1px solid #969595;
                    width: 2em;
                  ">
                                <i class="fa fa-chevron-right"
                                   aria-hidden="true"
                                   v-if="startIndex + MAXPAGE < jobTypes.length"
                                   @click="startIndex++"></i>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in sortedItems"
                            :key="index + 'ITEMCODES'"
                            :class="
                  item.isObsolete == true ? 'inactive-item' : 'active-item'
                ">
                            <td class="w-8 text-center">
                                <i v-if="item.isObsolete"
                                   class="fa fa-recycle text-white"
                                   @click="toggleActiveItem(item)"></i>
                                <i v-else
                                   class="fa fa-trash"
                                   @click="toggleActiveItem(item)"></i>
                            </td>
                            <td style="width: 5em; padding-left: 0.75rem">
                                <input class="jobTypeColumn form-input text-sm"
                                       :value="item.itemCode"
                                       maxlength="4"
                                       :readonly="item.isObsolete == true"
                                       @blur="updateItemCode(item, $event)" />
                            </td>
                            <td>
                                <input style="width: 100%"
                                       :value="item.itemName"
                                       :readonly="item.isObsolete == true"
                                       @blur="updateItemName(item, $event)" />
                            </td>
                            <td>
                                <input style="width: 100%"
                                       :value="item.itemDesc"
                                       :readonly="item.isObsolete == true" />
                            </td>
                            <td style="text-align: center">
                                <!-- Rounded switch -->
                                <label class="switch">
                                    <input type="checkbox"
                                           :readonly="item.isObsolete == true"
                                           :disabled="item.isObsolete == true"
                                           v-model="item.isTaxable" />
                                    <span class="slider round"></span>
                                </label>
                            </td>
                            <td class="jobTypeColumn" style="width: 2em">
                                <input style="width: 100%"
                                       class="jobTypeColumn text-right form-input"
                                       :readonly="item.isObsolete == true"
                                       :value="item.tax1" />
                            </td>
                            <td class="jobTypeColumn" style="width: 2em">
                                <input style="width: 100%"
                                       class="jobTypeColumn text-right form-input"
                                       :readonly="item.isObsolete == true"
                                       :value="item.tax2" />
                            </td>
                            <td></td>
                            <td class="jobTypeColumn"
                                v-for="(jobType) in filteredJobTypes"
                                @click="
                    selectedItem = item;
                    selectedJobType = jobType;
                  "
                                :key="`${jobType.jobTypeId}-${item.itemmCode}`"
                                :class="{'border-tracker-blue': isDirty(item, jobType),'inactive-item': jobType.isObsolete === true,}">
                                <div class="relative rounded" style="border:1px solid gray">
                                    <span class="absolute inset-y-0 left-0 flex items-center px-2 " @click="openDialog()" style="border-right:1px solid gray">
                                        <i :class="getItemTypeIcon(item, jobType)"></i>
                                    </span>
                                    <input class="jobTypeColumn form-input text-right"
                                           style="width:8em"
                                           autofocus
                                           readonly
                                           v-if="getValue(item, jobType).length > 1"
                                           value="STEP" />
                                    <input class="jobTypeColumn form-input"
                                           style="width:8em"
                                           autofocus
                                           :readonly="item.isObsolete == true || jobType.isObsolete == true"
                                           :placeholder="getPlaceHolder(item, jobType)"
                                           @blur="addFlatRate($event, item, jobType)"
                                           type="text"
                                           v-else-if="getValue(item, jobType).length == 0" />
                                    <input class="jobTypeColumn form-input"
                                           style="width:8em"
                                           @focus="{selectedItem = item;selectedJobType = jobType;}"
                                           :readonly="item.isObsolete == true || jobType.isObsolete == true"
                                           autofocus
                                           v-else
                                           type="text"
                                           @blur="updateFlatRate({
                                        amt: $event.target.value,
                                        item: item,
                                        jobType: jobType,
                                        selectedAccount: selectedAccount,
                                        selectedRate: selectedRate,
                                        itemRate: {
                                          ...getValue(item, jobType)[0],
                                        },
                                      })"
                                           :value="getValue(item, jobType)[0].amount" />
                                </div>
                                <!--<div style="position: relative">

                                  <div
                                    v-if="
                                      item.isObsolete == false &&
                                      selectedItem &&
                                      selectedItem.itemCode == item.itemCode &&
                                      jobType.isObsolete === false &&
                                      selectedJobType &&
                                      selectedJobType.shortCode == jobType.shortCode &&
                                      getValue(item, jobType).length > 0 &&
                                      getValue(item, jobType)[0].amount > 0
                                    "
                                    class="absolute w-6 pin-t z-50 text-center rounded-full bg-white shadow-md hover:shadow-lg hover:cursor-pointer group"
                                    style="right: -25px; top: -2px"
                                  >
                                    <i
                                      @click="
                                        handleCopyRight(getValue(item, jobType), jobIndex)
                                      "
                                      class="fa fa-chevron-right text-tracker-blue group-hover:text-tracker-blue-dark"
                                    ></i>
                                  </div>
                                </div>-->
                            </td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <BaseModal title="Add Step"
                   :showModal="showDialog"
                   @onCloseModal="showDialog = !showDialog"
                   :actions="[
                   {
                   Text: 'Clear Steps' ,
                   callback: ()=>
            {
            addStep();
            },
            },
            {
            Text: 'Add St<u>e</u>p',
            callback: () => {
            addStep();
            },
            shortkey: ['alt', 'e'],
            },
            ]"
            >
            <div class="flex w-96">
                <div class="flex text-left">
                    <label for="pullQuanitySrc" class="px-10">Pull Quantity From</label>
                    <select id="pullQuanitySrc">
                        <option>Manual</option>
                        <option>Storage</option>
                        <option>Milage</option>
                        <option>Timeline</option>
                    </select>
                </div>
                <div class="flex-1 text-right ml-10">
                    <table style="width: 100%; border: none">
                        <thead>
                            <tr>
                                <th>TierCount</th>
                                <th>Amount</th>
                            </tr>
                        </thead>
                        <tr v-for="(item, index) in getSteps" :key="index + 'STEPCODE'">
                            <td class="">
                                <div v-if="item.priority != 0">
                                    <input type="number"
                                           style="text-align: right"
                                           :value="item.tierCount" />
                                    <label for="itemTier" class="mr-4">Unit</label>
                                </div>
                                <span v-else>Thereafter</span>
                            </td>
                            <td class="">

                                <input type="number"
                                       style="text-align: right"
                                       :value="item.amount"
                                       @blur="
                    updateTierRate({
                      amt: $event.target.value,
                      jobType: selectedJobType,
                      itemCode: selectedItem.itemCode,
                      selectedAccount: selectedAccount,
                      selectedRate: selectedRate,
                      tierCount: item.tierCount,
                      priority: item.priority,
                    })
                  " />
                            </td>
                            <td class="">
                                <button class="text-red p-2">
                                    <i class="fa fa-times" v-if="item.priority != 0"></i>
                                </button>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </BaseModal> <!-- Add Item-->
        <BaseModal title="Add New Job Type"
                   :showModal="showAddJobTypeDialog"
                   @onCloseModal="showAddJobTypeDialog = !showAddJobTypeDialog"
                   size="small"
                   :actions="[
            {
            Text: 'Add Job Type',
            callback: () => {
            handleAddJobType();
            },
            shortkey: ['alt', 'e'],
            },
            ]"
            >

            >
            <div class="p-3">
                <form class="flex">
                    <div class="flex-1">
                        <div class="form-group p-2">
                            <label for="jobTypeCode" class="text-sm">Short Code:</label>
                            <input type="text" class="form-input" :value="newJobType.shortCode" autofocus required name="jobTypeCode" placeholder="AAAA" />
                            <span class="block text-xs">Helper text</span>
                        </div>
                        <div class="form-group p-2">
                            <label for="jobTypeCode" class="text-sm">Job Type:</label>
                            <input type="text" class="form-input" :value="newJobType.jobTypeName" required name="jobTypeName" placeholder="AAAA" />
                            <span class="block text-xs">Helper text</span>
                        </div>
                    </div>
                    <div class="flex-1 p-2">
                        <label for="jobTypeDescription" class="text-sm">Description</label>
                        <textarea id="jobTypeDescription" :value="newJobType.description" class="form-input" name="jobTypeDescription" cols="" role="" style="width:100%; height:80%" />
                        <span class="block text-xs">Helper text</span>
                    </div>
                </form>
            </div>

        </BaseModal>
    </div>

</template>
<script>
    import BaseModal from "./BaseModal";
    import { mapActions, mapState } from "vuex";
    export default {
        components: { BaseModal },
        name: "HelloWorld",
        props: {},
        data() {
            return {
                showAddJobTypeDialog: true,

                itemFilter: null,
                showDialog: false,
                MAXPAGE: 5,
                selectedRate: null,
                startIndex: 0,
                selectedAccount: null,
                selectedItem: null,
                selectedJobType: null,
                pageIndex: 0,
                newJobType: {
                    shortCode: "ABA",
                    jobTypeName: "Test",
                    description: "testtest"
                },
                jobTypes: [
                    {
                        jobTypeId: 20,
                        shortCode: "LDC",
                        jobTypeName: "Light Duty Tow/ Customer",
                        isObsolete: false,
                    },
                    {
                        jobTypeId: 21,
                        shortCode: "LD",
                        jobTypeName: "Light Duty Tow WHPD",
                        isObsolete: true,
                    },
                    {
                        jobTypeId: 22,
                        shortCode: "LD1",
                        jobTypeName: "Light Duty Tow REYPD",
                        isObsolete: false,
                    },
                    {
                        jobTypeId: 23,
                        shortCode: "DD",
                        jobTypeName: "Digital Dispatch",
                        isObsolete: false,
                    },
                    {
                        jobTypeId: 35,
                        shortCode: "HDT",
                        jobTypeName: "Heavy Duty Tow",
                        isObsolete: false,
                    },
                ],
            };
        },
        beforeMount() { },
        created() {
            //this.selectedRate = this.rates[0].rateId
            // console.log('test', this.$store);
            console.log("test2", this.selectedRate, this.$store.state.rates.all);
            //this.selectedRate = this.$store.state.rates.all[0].rateId;
        },
        mounted() {
            this.$nextTick(function () {
                console.log("test3", this.selectedRate, this.$store.state.rates.all);
                // Code that will run only after the
                // entire view has been rendered
                if (this.$store.state.rates.all.length > 0) {
                    this.selectedRate = this.$store.state.rates.all[0].rateId;
                }
            })
        },
        methods: {
            ...mapActions("itemRates", [
                "updateFlatRate",
                "updateTierRate",
                "copyItemRates",
            ]),

            toggleActiveItem(item) {
                this.$store.commit("itemRates/toggleActiveItem", item);
            },
            handleCopyRight(rates, index) {
                for (let i = index + 1 + this.pageIndex; i < this.jobTypes.length; i++) {
                    const jobType = this.jobTypes[i];

                    //const nextRates = this.getValue(this.selectedItem , jobType);
                    // Flat Rate
                    const newRates = rates.map((r) => {
                        return { ...r, jobTypeId: jobType.jobTypeId, isDirty: true };
                    });
                    this.copyItemRates({
                        itemCode: this.selectedItem.itemCode,
                        jobTypeId: jobType.jobTypeId,
                        selectedAccountId: this.selectedAccount,
                        selectedRateId: this.selectedRate,
                        newRates: newRates,
                    });
                }
            },
            addStep() {
                this.$store.dispatch("itemRates/addStepRate", {
                    selectedItem: this.selectedItem,
                    selectedAccount: this.selectedAccount,
                    selectedRate: this.selectedRate,
                    selectedJobType: this.selectedJobType,
                });

                //alert('test');
            },
            openDialog() {
                console.log(this.getValue(this.selectedItem, this.selectedJobType));
                if (this.getValue(this.selectedItem, this.selectedJobType).length < 1) {
                    this.addStep();
                }
                this.showDialog = true;
            },
            getItemTypeIcon(item, jobType) {
                let rateItems = [...item.itemRates].filter(
                    (r) =>
                        r.jobTypeId == jobType.jobTypeId &&
                        r.accountId === null &&
                        r.rateId === this.selectedRate
                );
                let result = null;
                if (rateItems.length > 0) {
                    let type = rateItems[0].data.name;
                    switch (type) {
                        case "Mileage Item Rate":
                            return "fa fa-road"
                        default:
                    }

                }
                console.log(result);
                return 'fas fa-toolbox';
            },
            getPlaceHolder(item, jobType) {
                let rateItems = [...item.itemRates].filter(
                    (r) =>
                        r.jobTypeId == jobType.jobTypeId &&
                        r.accountId === null &&
                        r.rateId === this.selectedRate
                );
                let result = null;
                if (rateItems.length > 1) {
                    result = "STEP";
                } else if (rateItems.length === 1) {
                    console.log(rateItems);
                    result = rateItems[0].amount;
                }
                return result;
            },
            isDirty(item, jobType) {
                let itemRate = this.getValue(item, jobType);
                //if (itemRate && itemRate.length == 1) return itemRate[0].isDirty;
                return itemRate.filter((r) => r.isDirty).length > 0;
            },
            getValue(item, jobType) {
                let rateItems = item.itemRates.filter(
                    (r) =>
                        r.jobTypeId == jobType.jobTypeId &&
                        r.accountId == this.selectedAccount &&
                        r.rateId == this.selectedRate
                );
                return rateItems;
            },

            addFlatRate(event, item, jobType) {
                let amt = event.target.value;
                if (amt === "") return;
                if (jobType === undefined) return;
                let flatRate = {
                    jobTypeId: jobType.jobTypeId,
                    rateId: this.selectedRate,
                    accountId: this.selectedAccount,
                    priority: 0,
                    amount: amt,
                    tierCount: 0,
                    isDirty: true,
                };
                item.itemRates.push(flatRate);
            },
            updateItemCode(item, event) {
                item.itemCode = event.target.value;
            },
            updateItemName(item, event) {
                item.itemName = event.target.value;
            },
            handleAddItem() {
                this.items.push({
                    isDirty: true,
                    isObsolete: false,
                    itemCode: "",
                    itemName: "",
                    isTaxable: false,
                    itemRates: [],
                });
                this.$nextTick(() => {
                    const rows = document.getElementsByClassName("active-item");
                    console.log(rows);
                    const lastRow = rows[0];
                    lastRow.getElementsByTagName("input")[0].focus();
                });
            },
            handleAddJobType() {
                this.jobTypes.push({
                    jobTypeId: 0,
                    shortCode: "",
                    jobTypeName: "",
                });
                if (this.jobTypes.length > this.MAXPAGE) {
                    this.startIndex++;
                }
                this.showAddJobTypeDialog = false;
            },
            handleNewJobTypeClick() {
                console.log('warning1');
                this.showAddJobTypeDialog = true;

            },
            handleSaveOtherClick() {
                console.log('warning2');
            },
            handleSaveClick() {
                console.log('warning');
                this.items.forEach((item) => {
                    var dirtyItemRates = item.itemRates.filter((i) => i.isDirty === true);
                    dirtyItemRates.forEach((dir) => (dir.isDirty = false));
                });
            },
        },
        computed: {
            ...mapState({
                accounts: (state) => state.accounts.all,
                rates: (state) => state.rates.all,
                items: (state) => state.itemRates.all,
            }),

            sortedItems: function () {
                return [...this.items]
                    .sort((r) => {
                        return r.isObsolete ? 1 : -1;
                    })
                    .filter(
                        (r) =>
                            this.itemFilter == null ||
                            r.itemCode.includes(this.itemFilter) ||
                            r.itemName.includes(this.itemFilter)
                    );
            },
            getSteps: function () {
                if (this.selectedItem == null || this.selectedJobType == null) return [];
                console.log(this.selectedItem);
                console.log(this.selectedJobType);
                let rateItems = [...this.selectedItem.itemRates].filter(
                    (r) =>
                        r.jobTypeId == this.selectedJobType.jobTypeId &&
                        r.accountId === this.selectedAccount &&
                        r.rateId === this.selectedRate
                );
                return rateItems.sort((a, b) => {
                    if (a.priority < b.priority) {
                        return 1;
                    }
                    if (a.priority > b.priority) {
                        return -1;
                    }
                    return 0;
                });
            },
            getDirtyStatus: function () {
                return this.items.filter((r) => r.isDirty).length > 0;
            },
            jobIndex: function () {
                if (this.startIndex < 0) return 0;
                if (this.jobTypes.length - this.startIndex) return this.MAXPAGE;
                return this.startIndex;
            },
            filteredJobTypes: function () {
                let result = [];
                for (let i = 0; i < this.MAXPAGE; i++) {
                    if (i + this.startIndex >= this.jobTypes.length) break;
                    const element = this.jobTypes[i + this.startIndex];
                    result.push(element);
                }
                return result;
            },
        },
    };
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
    th {
        text-align: left;
        vertical-align: bottom;
        padding: 5px;
    }

    label {
        padding: 0;
        margin: 0;
    }

    table.rateTable td {
        border: 1px solid #969595;
        padding: 5px;
    }

    table.rateTable td,
    table.rateTable th,
    td input {
        cursor: pointer;
    }

    .jobTypeColumn {
        width: 5em;
    }

        .jobTypeColumn input[type="text"] {
            border: none;
            width: 100%;
            text-align: right;
        }

    select {
        height: 2em;
        border: 1px solid #969595;
        padding: 5px;
    }

    button:focus,
    button:active {
        outline: none;
        outline: 0;
    }

    button:hover {
        -webkit-box-shadow: -5px 5px 0px -2px rgba(0, 0, 0, 0.58);
        -moz-box-shadow: -5px 5px 0px -2px rgba(0, 0, 0, 0.58);
        box-shadow: -5px 5px 0px -2px rgba(0, 0, 0, 0.58);
    }

    button:active {
        -webkit-box-shadow: inset -5px -5px 5px -2px rgba(0, 0, 0, 0.58);
        -moz-box-shadow: inset -5px -5px 5px -2px rgba(0, 0, 0, 0.58);
        box-shadow: inset -5px -5px 5px -2px rgba(0, 0, 0, 0.58);
    }

    button:active {
        -webkit-box-shadow: -5px -5px 5px -2px rgba(0, 0, 0, 0.58);
        -moz-box-shadow: -5px -5px 5px -2px rgba(0, 0, 0, 0.58);
        box-shadow: -5px -5px 5px -2px rgba(0, 0, 0, 0.58);
    }

    input:focus {
        border: none;
    }

    *:focus {
        outline: none;
    }

    .btn {
        color: #18a2cf;
        background-color: #fff;
        font-weight: 700;
        padding: 15px 25px;
        text-align: center;
        cursor: pointer;
        outline: none;
        border: none;
        border-radius: 15px;
        box-shadow: 0 9px #999;
        border-bottom: 2px solid transparent;
        border-left: 1px solid transparent;
    }

        .btn:hover {
            background-color: white;
            color: #18a2cf;
            /* border-bottom:2px solid black; */
            border-left: 1px solid #969595;
            border-bottom: 1px solid #969595;
        }

        .btn:active {
            background-color: white;
            color: #18a2cf;
            box-shadow: none;
            transform: translateY(4px) translateX(-4px);
        }

    .bg-tracker-blue {
        background-color: #18a2cf;
    }

    .text-tracker-orange {
        color: #f47424;
    }

    .btn {
        padding-left: 1.5rem;
        padding-right: 1.5rem;
        padding-top: 0.75rem;
        padding-bottom: 0.75rem;
        border-radius: 0.25rem;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.12), 0 2px 4px 0 rgba(0, 0, 0, 0.08);
        width: auto;
    }
    /* The switch - the box around the slider */
    .switch {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 24px;
    }
        /* Hide default HTML checkbox */
        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
    /* The slider */
    .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        -webkit-transition: 0.4s;
        transition: 0.4s;
    }

        .slider:before {
            position: absolute;
            content: "";
            height: 16px;
            width: 16px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            -webkit-transition: 0.4s;
            transition: 0.4s;
        }

    input:checked + .slider {
        background-color: #2196f3;
    }

    input:focus + .slider {
        box-shadow: 0 0 1px #2196f3;
    }

    input:checked + .slider:before {
        -webkit-transform: translateX(16px);
        -ms-transform: translateX(16px);
        transform: translateX(16px);
    }
    /* Rounded sliders */
    .slider.round {
        border-radius: 24px;
    }

        .slider.round:before {
            border-radius: 50%;
        }

    .border-tracker-blue {
        background-color: #18a2cf;
    }

        .border-tracker-blue input {
            font-weight: bold;
        }

    input:focus {
        border: 1px solid #003361;
    }

    .inactive-item,
    .inactive-item input {
        background-color: gray;
        text-decoration: line-through;
    }

    label {
        display: block;
    }

    .searchItem {
        height: 2em;
        border: 1px solid #969595;
    }

    .active-item td {
        height: 37px;
    }

    .tracker-border-gray {
        border: 1px solid #969595;
    }
</style>