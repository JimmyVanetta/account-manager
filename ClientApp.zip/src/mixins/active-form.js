import Vue from "vue";

let nextInstanceNo = 1;

let SHAREDDATA = Vue.observable({
  isActive: false,
  activeFormId: 0
});

export var mixin = {
  created() {
    // Don't make this observable
    this.$_idForActiveForm = nextInstanceNo;
    nextInstanceNo++;
  },

  computed: {
    isSomeFormCurrentlyActive() {
      return SHAREDDATA.isActive;
    },

    isCurrentlyActiveForm() {
      return (
        SHAREDDATA.isActive &&
        SHAREDDATA.activeFormId === this.$_idForActiveForm
      );
    }
  },

  methods: {
    becomeActiveForm() {
      SHAREDDATA.isActive = true;
      SHAREDDATA.activeFormId = this.$_idForActiveForm;
    },

    resignActiveForm() {
      SHAREDDATA.isActive = false;
    }
  }
};
