export var mixin = {
  mounted() {
    this.$_escapeListener = e => {
      if (e.keyCode === 27 && this.onEscapeKey) {
        this.onEscapeKey(e);
      }
    };
    document.addEventListener("keydown", this.$_escapeListener);
  },

  beforeDestroy() {
    document.removeEventListener("keydown", this.$_escapeListener);
  }
};
