let nextId = 1;

export var mixin = {
  beforeCreate() {
    this.componentId = `component${nextId}`;
    nextId += 1;
  }
};
