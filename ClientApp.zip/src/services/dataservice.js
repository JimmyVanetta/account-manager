export default class DataService{


    static async Test(){
        return new Promise((resolve) => {
            setTimeout(function(){
                resolve([{
                    itemCode: "DEMO",
                    itemName: "Demo Item",
                    isTaxable: true,
                    tax1:2.00,
                    tax2:6.75,
                    itemRates: [{
                      jobTypeId: 1,
                      rateId: 1,
                      accountId: null,
                      priority: 0,
                      amount: 0,
                      tierCount: 0,
                      isDirty: false
                    }]
                  },
                  {
                    itemCode: "STR",
                    itemName: "Storage",
                    isTaxable: false,
                    itemRates: [{
                        jobTypeId: 1,
                        rateId: 1,
                        accountId: null,
                        priority: 0,
                        amount: 10,
                        tierCount: 0,
                        isDirty: false
                      },
                      {
                        jobTypeId: 1,
                        rateId: 1,
                        accountId: 0,
                        priority: 0,
                        amount: 20.00,
                        tierCount: 0,
                        isDirty: false
                      }
                    ]
                  }
                ]);
            }, 1000);
        });
    }
}